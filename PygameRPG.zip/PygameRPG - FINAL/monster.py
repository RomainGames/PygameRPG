###########################
#                         #
#        PygameRPG        #
#      Romain Lafosse     #
#                         #
#        Python 3.7.7     #
#        Thonny 3.2.7     #
#                         #
###########################
import pygame,random,time

class Monster(pygame.sprite.Sprite):
    """Définit les monstres du jeu"""
    def __init__(self,screen,game,lieu,message,level=None,mini_boss=False):
        """Initialise les monstres, avec leur points de vie, par rapport à leur niveau choisit aléatoirement
            On doit lui définir l'écran, la classe game, le lieu, et on peut lui donner un niveau précis, et lui donner des attributs de mini_boss"""
        super().__init__()
        self.game = game
        self.mini_boss = mini_boss
        self.screen = screen
        if level==None:
            if lieu == "Forest":
                if self.game.player.level <= 3:
                    self.level = random.randint(1,self.game.player.level+2)
                else:
                    self.level = random.randint(self.game.player.level-2,self.game.player.level+2)
            else:
                self.level = self.game.player.level + random.randint(0,4)
        elif level != None:
            self.level = level
        self.message = message
        self.health = 10+self.level
        self.max_health = 10+self.level
        self.attack = 2+(self.level*0.5)
        self.speed = 4+(self.level//5)
        self.image = pygame.image.load('assets\\'+lieu+'\\monster.png')
        self.image = pygame.transform.scale(self.image,(100,200))
        self.rect = self.image.get_rect()
        self.rect.y = 350
        self.xp = self.level
        self.can_move = True
        if mini_boss:
            self.image = pygame.image.load('assets\\'+lieu+'\\into_magma_castle\\guard_left.png')
            self.image = pygame.transform.scale(self.image,(100,200))
            

    def damage(self,amount,direction):
        """Inflige les dégats au monstre, avec des dégats précis et une direction précise"""
        #infliger dégats
        self.health -= amount
        if direction == '_left' and self.rect.x < 1040:
            if self.mini_boss:
                self.rect.x -= 100
            else:
                self.rect.x -= 50
        elif self.rect.x > -10:
            if self.mini_boss:
                self.rect.x += 150
            else:
                self.rect.x += 75

        #Vérifier si il est mort
        if self.health <=0:
            self.game.all_monsters.remove(self)
            self.game.player.xp += self.xp
            self.game.nb_monstres_tues += 1
            if not(self.game.in_miniboss_fight) and self.message:
                time.sleep(0.1)
                self.game.message(ligne1="Vous avez tué un monstre de niveau "+str(self.level)+" !",ligne2="Vous avez gagné "+str(self.xp)+" d'XP !")
            elif self.game.in_miniboss_fight:
                game = self.game
                self.game.cant_save = True
                self.game.player.can_move = False
                self.game.message(ligne1="Argh, tu m'as battu..",speaker = "???",speaker_color = game.color.gray())
                self.game.message(ligne1="Avant d'y aller, laisse moi te donner",ligne2="un dernier conseil",speaker = "???",speaker_color = game.color.gray())
                self.game.message(ligne1="Monte jusqu'au niveau 25",ligne2="Elle est vraiment forte",speaker = "???",speaker_color = game.color.gray())
                self.game.player.can_move = True
                self.game.in_miniboss_fight = False
                self.game.mini_boss_fight = True
                self.game.cant_castle = False
                self.game.all_monsters.remove(self)
                time.sleep(0.1)
                self.game.message(ligne1="Vous avez tué un '???' de niveau "+str(self.level)+" !",ligne2="Vous avez gagné "+str(self.xp)+" d'XP !")
                self.game.player.xp += self.xp
                self.game.nb_monstres_tues += 1
                game.cant_transition = False
                game.cant_castle = False
                self.game.cant_save = False
                self.game.player.health = self.game.player.max_health
                self.game.message(ligne1="Votre vie a entièrement été regénéré.")


    def forward(self):
        """Fait avancer les monstres suivant la position du joueur"""
        #le déplacement ne se fait que si ya pas de joueur
        if self.rect.x < self.game.player.rect.x-45:
            self.rect.x += self.speed
        elif self.rect.x > self.game.player.rect.x+45:
            self.rect.x -= self.speed
        else:
            if self.rect.x<self.game.player.rect.x:
                self.game.player.damage(self.attack,'')
            else:
                self.game.player.damage(self.attack,'_left')
    
    def update_health_bar(self, surface):
        """Met à jour la barre de vie du monstre"""
        #dessiner barre de vie
        if self.mini_boss:
            pygame.draw.rect(surface,(172,9,9),[self.rect.x, self.rect.y, 100, 10])
            pygame.draw.rect(surface, (111,210,46), [self.rect.x, self.rect.y, (self.health/self.max_health)*100, 10])
        else:
            pygame.draw.rect(surface,(172,9,9),[self.rect.x, self.rect.y+100, 100, 10])
            pygame.draw.rect(surface, (111,210,46), [self.rect.x, self.rect.y+100, (self.health/self.max_health)*100, 10])


