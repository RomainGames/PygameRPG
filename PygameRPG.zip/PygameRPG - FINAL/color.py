class Color():
    """ Class permettant de renvoyer directement les codes des couleurs définit, sans devoir taper à chaque fois ce code couleur.
        Ici, le code couleur utilisé est le RGB, en donnant 3 valeurs allant de 0 à 255
        
        Le site https://htmlcolorcodes.com/fr/ m'a permit d'avoir tous ces codes couleurs très facilement
        
        Pour utiliser ces couleurs, il suffit donc de créer un objet en utilisant la classe Color, (par exemple color = Color())
        puis d'appeler une de ces fonctions, qui va renvoyer le code couleur.
        Par exemple:
        color.black() va donner les codes couleurs pour le noir, soit (0,0,0)
        
        >>>color.black()
        (0,0,0)
    """
    
    
    def black(self):
        return (0,0,0)
    
    def white(self):
        return (255,255,255)
    
    def gray(self):
        return (100,99,99)
    
    def pink(self):
        return (247,44,173)
    
    def red(self):
        return (220,11,11)
    
    def boss_color(self):
        return (151,37,0)