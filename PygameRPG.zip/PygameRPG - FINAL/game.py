###########################
#                         #
#        PygameRPG        #
#      Romain Lafosse     #
#                         #
#        Python 3.7.7     #
#        Thonny 3.2.7     #
#                         #
###########################
"""Fichier le plus important, puisque c'est lui qui gère la plupart du jeu, en dehors du fichier main.py """

"""Il import tous les autres fichiers, pour tout regrouper"""
import pygame
import string
from player import Player
from monster import Monster
import time
import ctypes
from pnj import Pnj
from color import Color
from menu import Menu
from save import Save
from boss import Boss
from projectile import Projectile
#Lien d'origine du code pour les vibrations : https://stackoverflow.com/questions/20499946/xbox-360-vibrate-rumble
class XINPUT_VIBRATION(ctypes.Structure):
    """Classe des vibrations de la manette"""
    _fields_ = [("wLeftMotorSpeed", ctypes.c_ushort),
                ("wRightMotorSpeed", ctypes.c_ushort)]

xinput = ctypes.windll.xinput1_1  # Load Xinput.dll

# Set up function argument types and return type
XInputSetState = xinput.XInputSetState
XInputSetState.argtypes = [ctypes.c_uint, ctypes.POINTER(XINPUT_VIBRATION)]
XInputSetState.restype = ctypes.c_uint

# Now we're ready to call it.  Set left motor to 100%, right motor to 50%
# for controller 0
vibration = XINPUT_VIBRATION(65535, 32768)
XInputSetState(0, ctypes.byref(vibration))

# You can also create a helper function like this:
def set_vibration(controller, left_motor, right_motor):
    """ Fait  vibrer la manette:
        left_motor et right_motor prenne une valeur entre 0 et 1, qui représente l'intensité des vibrations pour chaque moteur"""
    vibration = XINPUT_VIBRATION(int(left_motor * 65535), int(right_motor * 65535))
    XInputSetState(controller, ctypes.byref(vibration))
set_vibration(0,0,0) #On empèche la manette de vibrer



class Game:
    """Classe principal du jeu"""
    def __init__(self,screen):
        """Initialisation de tous les objets, class, fond d'écran du jeu"""
        self.screen = screen
        self.save = Save(self)
        self.color = Color()
        self.boss = Boss(self.screen,self)
        self.all_projectiles = pygame.sprite.Group() #Groupe des Sprites des projectiles
        self.pressed = {}
        self.lieu2 = ""
        self.text_background = pygame.image.load('assets//text.png')
        self.text_background = pygame.transform.scale(self.text_background,(self.screen.get_width(),self.screen.get_height()))
        self.text_background_rect = self.text_background.get_rect()
        self.dont_spawn = False
        self.princess = Pnj('into_castle','princess',900,'left',self.screen) #Les pnjs du château de la forêt
        self.guard = Pnj('into_castle','guard',750,'right',self.screen)
        
        self.all_monsters = pygame.sprite.Group() #Groupe des Sprites des monstres
        self.new_zone = False   
        self.nb_monstres_tues = 0
        """Variable permettant de bloquer certaines fonctionnalités du jeu"""
        self.cant_castle = False
        self.cant_transition = False
        self.cant_save = False
        self.in_boss_fight = False
        self.in_attack = False
        self.cant_damage = False
        
        self.menu = Menu(self)
        self.save = Save(self)
    
    def load_player(self,id_save):
        """Charge toutes les données des sauvegardes. Il suffit de donner la clé principale de la sauvegarde, et on utilise la class save
            pour mettre en place toutes les variables, dont le lieu du joueur, sa vie, son niveau, etc...
        """
        health,max_health,level,attack,speed,self.zone,self.lieu,x,xp_next_level,xp,self.tuto,self.monster_can_spawn,self.save.save_name,self.first_time_cinematique,self.princess_quest,self.princess_pass,self.mini_boss_fight,self.boss_already_fight,self.last_cinematique = self.save.load(id_save)
        self.first_time_castle = True
        self.player = Player(self.screen,self,health,max_health,level,xp,xp_next_level,attack,speed,x)
        try:
            self.zone = int(self.zone)
        except:
            self.zone = self.zone
        if self.lieu != "into_castle" and self.lieu != "into_magma_castle":
            self.background = pygame.image.load('assets/'+self.lieu+'/background/background_'+str(self.zone)+'.png')
            self.background = pygame.transform.scale(self.background,(self.screen.get_width(),self.screen.get_height()))
        elif self.zone == "into_1" and self.lieu == "into_castle":
            self.background = pygame.image.load('assets/castle/into_castle/into_castle_1.png')
            self.background = pygame.transform.scale(self.background,(self.screen.get_width(),self.screen.get_height()))
            self.lieu2 = "castle"
        elif self.lieu == "into_castle":
            self.background = pygame.image.load('assets/castle/into_castle/into_castle_trone.png')
            self.background = pygame.transform.scale(self.background,(self.screen.get_width(),self.screen.get_height()))
            self.lieu2 = "castle"
        elif self.zone == "into_1" and self.lieu == "into_magma_castle":
            self.background = pygame.image.load('assets/magmatown/into_magma_castle/into_castle_1.png')
            self.background = pygame.transform.scale(self.background,(self.screen.get_width(),self.screen.get_height()))
            self.lieu2 = "magmatown"
        elif self.lieu == "into_magma_castle":
            self.background = pygame.image.load('assets/magmatown/into_magma_castle/into_castle_trone.png')
            self.background = pygame.transform.scale(self.background,(self.screen.get_width(),self.screen.get_height()))
            self.lieu2 = "magmatown"
        self.background_rect = self.background.get_rect()

        self.text_background = pygame.image.load('assets/text.png')
        self.text_background = pygame.transform.scale(self.text_background,(self.screen.get_width(),self.screen.get_height()))
        self.text_background_rect = self.text_background.get_rect()
        
    
    def zone_change_right(self):
        """Permet un changement de zone vers la droite"""
        if not(self.cant_transition):
            self.transition_pt1()
            self.player.rect.x = -5
            if type(self.zone) == int:
                self.zone+=1
            else:
                self.zone = 1
            if self.lieu == "Forest" and self.zone > 3:
                self.lieu = "castle"
                self.zone = 'castle'
            elif self.lieu == "castle" and self.zone > 3:
                self.lieu = "magmatown"
                self.zone = 1
            elif self.lieu == "magmatown" and self.zone > 3:
                self.zone = "castle"
            self.background = pygame.image.load('assets/'+self.lieu+'/background/background_'+str(self.zone)+'.png')
            self.background = pygame.transform.scale(self.background,(self.screen.get_width(),self.screen.get_height()))
            self.all_monsters = pygame.sprite.Group()
            self.transition_pt2()
            self.new_zone = True           
            return True
    
    def transition_pt1(self):
        """Cette transition fait un fondu vers le noir"""
        if self.dont_spawn:
            self.dont_spawn = False
        transition =  pygame.image.load('assets/black.png')
        transition = pygame.transform.scale(transition,(self.screen.get_width(),self.screen.get_height()))
        transition_rect = transition.get_rect()
        self.screen.blit(transition, transition_rect)
        transition.set_alpha(0)
        for i in range(8):
            transition.set_alpha(i*32)
            self.screen.blit(self.background, self.background_rect)
            self.screen.blit(self.player.image, self.player.rect)
            self.all_monsters.draw(self.screen)
            self.player.update_health_bar(self.screen)
            self.screen.blit(transition, transition_rect)
            pygame.display.update()
    def transition_pt2(self):
        """Cette transition fait l'inverse que celle pt1
            Les deux cumulés font donc une transition avec un fondu au noir"""
        transition =  pygame.image.load('assets/black.png')
        transition = pygame.transform.scale(transition,(self.screen.get_width(),self.screen.get_height()))
        transition_rect = transition.get_rect()
        self.screen.blit(transition, transition_rect)
        transition.set_alpha(255)
        for i in range(8):
            transition.set_alpha(255-(i*32))
            self.screen.blit(self.background, self.background_rect)
            self.screen.blit(self.player.image, self.player.rect)
            self.all_monsters.draw(self.screen)
            self.player.update_health_bar(self.screen)
            self.screen.blit(transition, transition_rect)
            pygame.display.update()
        pygame.draw.rect(self.screen,(0,0,0),[0, 0, 0, 0])
        pygame.display.update()
        
        
        
    
    def zone_change_left(self):
        """Change de zone vers la gauche"""
        if not(self.cant_transition):
            self.transition_pt1()    
            self.player.rect.x = self.screen.get_width()-63
            if self.lieu == "castle" and self.zone == 1:
                self.zone = 'castle'
            elif self.lieu == "castle" and self.zone == 'castle':
                self.lieu = "Forest"
                self.zone = 3
            elif self.lieu == "magmatown" and self.zone ==1:
                self.lieu = "castle"
                self.zone = 3
            elif self.lieu == "magmatown" and self.zone == "castle":
                self.zone = 3
            else:
                self.zone -= 1
        
            self.background = pygame.image.load('assets/'+self.lieu+'/background/background_'+str(self.zone)+'.png')
            self.background = pygame.transform.scale(self.background,(self.screen.get_width(),self.screen.get_height()))
            self.all_monsters = pygame.sprite.Group()
            self.transition_pt2()
            self.new_zone = True
            return True

    def check_collision(self,sprite,group):
        """Vérifie les collision entre le joueur et un objet"""
        return pygame.sprite.spritecollide(sprite,group,False,pygame.sprite.collide_mask)

    def set_vibration(self,controller, left_motor, right_motor):
        """Permet de mettre des vibrations sur la manette"""
        vibration = XINPUT_VIBRATION(int(left_motor * 65535), int(right_motor * 65535))
        XInputSetState(controller, ctypes.byref(vibration))

    def spawn_monster(self,x,niveau=None,miniboss = False):
        """Fait apparaitre un monstre, et le rajoute dans le groupe de sprite all_monsters"""
        lieu = "Forest"
        message = True
        if self.lieu == "magmatown":
            lieu = "magmatown"
        elif self.lieu == "into_magma_castle":
            lieu = "magmatown"
            message = False
        monster = Monster(self.screen,self,lieu,message,level=niveau, mini_boss=miniboss)
        monster.rect.x = x
        self.all_monsters.add(monster)
    
    def spawn_projectile(self):
        """Fait apparaitre un projectile, et le rajoute dans le groupe de sprite all_projectiles"""
        projectile = Projectile(self)
        if projectile.pos == "right":
            projectile.rect.x = self.boss.rect.x + 50
        elif projectile.pos == "left":
            projectile.rect.x = self.boss.rect.x - 50
        self.all_projectiles.add(projectile)
        
    
    def enter_castle(self):
        """Permet d'entrer dans le château"""
        if not(self.cant_castle):
            self.transition_pt1()
            self.lieu2 = self.lieu
            if self.lieu == "magmatown":
                self.lieu = "into_magma_castle"
            else:
                self.lieu = "into_castle"
            self.zone = "into_1"
            self.background = pygame.image.load('assets\\'+self.lieu2+'\\'+self.lieu+'\\into_castle_1.png')
            self.background = pygame.transform.scale(self.background,(self.screen.get_width(),self.screen.get_height()))
            self.transition_pt2()
    
    def exit_castle(self):
        """Permet de sortir du château"""
        self.transition_pt1()
        if self.lieu == "into_magma_castle":
            self.lieu = "magmatown"
        else:
            self.lieu = "castle"
        self.zone = "castle"
        self.lieu2 = ""
        self.background = pygame.image.load('assets/'+self.lieu+'/background/background_'+str(self.zone)+'.png')
        self.background = pygame.transform.scale(self.background,(self.screen.get_width(),self.screen.get_height()))
        self.transition_pt2()
        
    
    def message(self,ligne1="",ligne2="",speaker = None, speaker_color = None, choice = False, ask = False):
        """
        Fonction qui permet d'envoyer un message sur l'écran du joueur.
        Pour l'activer, il faut mettre 'ligne'+ le numéro de la ligne, et appliquer à cette variable ce que l'on veut afficher à cette ligne
        Exemple
        message(ligne1='Salut') va afficher 'Salut' à la ligne 1
        On peut aussi rajouter une personne qui parle, mais dans ces cas la il faut aussi lui rajouter une couleur !
        Pour cela, il faut utiliser speaker et speaker_color
        message(ligne1="Salut",speaker = "Moi",color = game.color.black()) va afficher, en plus du "Salut", Moi en noir au dessus du texte (et en petit)
        
        On peut demander au joueur d'écrire (limité à 20 charactères) avec ask = True
        
        On peut faire un choix pour le joueur (oui ou non) avec choice = True
        """
        l1=ligne1
        l2=ligne2
        try:
            self.player.can_move = False
        except:
            print()
        self.pressed[pygame.K_RIGHT] = False
        self.pressed[pygame.K_LEFT] = False
        self.pressed[pygame.K_d] = False
        self.pressed[pygame.K_q] = False
        font=pygame.font.Font(None, 24)
        self.screen.blit(self.text_background, self.text_background_rect)
        skip = False
        baisse_texte = 0
        if speaker!=None:
            baisse_texte += 50
            texte_a_afficher = pygame.font.Font(None, 24).render(speaker,1,speaker_color)
            self.screen.blit(texte_a_afficher, (30, 30))
            pygame.display.flip()
        if l1 != "":
            texte_en_cours = ""
            for i in range(len(l1)):
                if not skip:
                    font=pygame.font.Font(None, 50)
                    if l1[i] != " ":
                        texte_en_cours += l1[i]
                        texte_a_afficher = font.render(texte_en_cours,1,(255,255,255))
                        self.screen.blit(texte_a_afficher, (30, 30+baisse_texte))
                        pygame.mixer.music.load("assets/text_regular.ogg")
                        pygame.mixer.music.play()
                        time.sleep(0.1)
                        pygame.display.flip()
                    else:
                        texte_en_cours += l1[i]
                    for event in pygame.event.get():
                        if event.type == pygame.KEYDOWN:
                            if event.key == pygame.K_SPACE:
                                skip = True
                        elif event.type == pygame.JOYBUTTONDOWN:
                            if event.button == 0 or event.button == 1:
                                skip = True

                else:
                    texte_a_afficher = font.render(ligne1,1,(255,255,255))
                    self.screen.blit(texte_a_afficher, (30, 30+baisse_texte))
                    pygame.display.flip()
                    break
        if l2!="":
            texte_en_cours = ""
            for i in range(len(l2)):
                if not skip:
                    font=pygame.font.Font(None, 50)
                    if l2[i] != " ":
                        texte_en_cours += l2[i]
                        texte_a_afficher2 = font.render(texte_en_cours,1,(255,255,255))
                        self.screen.blit(texte_a_afficher2, (30, 80+baisse_texte))
                        pygame.mixer.music.load("assets/text_regular.ogg")
                        pygame.mixer.music.play()
                        time.sleep(0.1)
                        pygame.display.flip()
                    else:
                        texte_en_cours += l2[i]
                    for event in pygame.event.get():
                        if event.type == pygame.KEYDOWN:
                            if event.key == pygame.K_SPACE:
                                skip = True
                        elif event.type == pygame.JOYBUTTONDOWN:
                            if event.button == 0:
                                skip = True

                else:
                    texte_a_afficher = font.render(l2,1,(255,255,255))
                    self.screen.blit(texte_a_afficher, (30, 80+baisse_texte))
                    pygame.display.flip()
                    break
        skip = False
        if ask:
            texte_a_afficher = font.render(l1,1,(255,255,255))
            texte_a_afficher2 = font.render(l2,1,(255,255,255))
            save_name = []
            compteur = 0
            maj = False
            clear = False
            space = False
            while ask:
                self.screen.blit(self.background,self.background_rect)
                font=pygame.font.Font(None, 60)
                self.screen.blit(self.text_background, self.text_background_rect)
                self.screen.blit(texte_a_afficher, (30, 30+baisse_texte))
                self.screen.blit(texte_a_afficher2, (30, 80+baisse_texte))
                for event in pygame.event.get():
                    if event.type == pygame.KEYDOWN:
                        if (event == pygame.K_BACKSPACE or event.key == 8) and len(save_name)>=1:
                            save_name.pop()
                            clear = True
                        elif event.key == pygame.K_SPACE and len(save_name)<20:
                            save_name.append(" ")
                            space = True
                        elif event.key == pygame.K_RETURN:
                            affichage = ""
                            for i in save_name:
                                affichage += i
                            return affichage
                                
                        elif event.key == pygame.K_LSHIFT:
                            maj = True
                        
                        elif len(save_name)<=20:
                            if event.key < 1000:
                                append = False                               
                                for letter in string.printable:
                                    if letter == chr(event.key) and append == False:
                                        if maj:
                                            try:
                                                save_name.append(chr(event.key).upper())
                                            except:
                                                save_name.append(chr(event.key))
                                        else:
                                            save_name.append(chr(event.key))
                                        append = True
                                if append == False:
                                    for chara in string.punctuation:
                                        if chara == chr(event.key) and append == False:
                                            save_name.append(chr(event.key))
                                            append = True
                                    
                    elif event.type == pygame.KEYUP:
                        if event.key == pygame.K_LSHIFT:
                            maj = False
                        elif event.key == pygame.K_BACKSPACE or event.key == 8:
                            clear = False
                        elif event.key == pygame.K_SPACE:
                            space = False
                                    
                                
                                
                                    
                affichage = ""
                for i in save_name:
                    affichage += i
                if compteur<5:
                    affichage += "|"
                elif compteur<10:
                    affichage += " "
                else:
                    affichage += "|"
                    compteur = 0
                afficher = font.render(affichage,1,self.color.black())
                afficher_rect = afficher.get_rect()
                afficher_rect.x = self.screen.get_width()/4
                afficher_rect.y = 500
                self.screen.blit(afficher,afficher_rect)
                pygame.display.flip()
                compteur += 1
                time.sleep(1/60) 
        elif choice:
            texte_a_afficher = font.render(l1,1,(255,255,255))
            texte_a_afficher2 = font.render(l2,1,(255,255,255))
            selecteur = -2
            appuie = False
            nb_joysticks = pygame.joystick.get_count()
            if nb_joysticks > 0:
                mon_joystick = pygame.joystick.Joystick(0)
                mon_joystick.init()
            manette_used = False
            back = False
            while choice:
                self.screen.blit(self.background,self.background_rect)
                font=pygame.font.Font(None, 40)
                oui = font.render("oui",1,(0,0,0))
                non = font.render("non",1,(0,0,0))
                oui_rect = oui.get_rect()
                non_rect = non.get_rect()
                oui_rect.y = non_rect.y = 600
                oui_rect.x = 400
                non_rect.x = 600
                try:
                    self.screen.blit(game.background, game.background_rect)
                    self.screen.blit(game.princess.image, game.princess.rect)
                    self.screen.blit(game.player.image, game.player.rect)
                    self.screen.blit(game.guard.image,game.guard.rect)
                    self.screen.blit(game.guard.image,game.guard.rect)
                except:
                    print(end="")
                self.screen.blit(oui, oui_rect)
                self.screen.blit(non, non_rect)
                self.screen.blit(self.text_background, self.text_background_rect)
                self.screen.blit(texte_a_afficher, (30, 30+baisse_texte))
                self.screen.blit(texte_a_afficher2, (30, 80+baisse_texte))
                pygame.display.flip()
                for event in pygame.event.get():
                    if pygame.joystick.get_init():
                        if event.type == pygame.JOYBUTTONDOWN:
                            if event.button == 0:
                                appuie = True
                            elif event.button == 1:
                                back = True
                        elif event.type == pygame.JOYBUTTONDOWN:
                            if event.button == 0:
                                appuie = False
                            elif event.button == 1:
                                back = False
                            
                        if manette_used and selecteur == -2:
                            selecteur == 1
                        if event.type == pygame.JOYHATMOTION:
                            if manette_used == False:
                                manette_used = True
                                selecteur = 1
                            elif event.value[1] == 0:
                                if event.value[0] == -1 and selecteur == 2: #Gauche
                                    selecteur -= 1 
                                elif event.value[0] == 1 and selecteur == 1: #Droite
                                    selecteur += 1
                    else:
                        pass
                    
                pos2 = pygame.mouse.get_pos()
                pressed1, pressed2, pressed3 = pygame.mouse.get_pressed()
                if oui_rect.collidepoint(pos2) or selecteur == 1:
                    play_button = pygame.image.load('assets/play_button_mousing.png')
                    play_button = pygame.transform.scale(play_button,(abs(oui_rect.w+30),abs(oui_rect.h+20)))
                    play_button_rect = play_button.get_rect()
                    play_button_rect.x = oui_rect.x-10
                    play_button_rect.y = oui_rect.y-10
                    self.screen.blit(play_button,play_button_rect)
                    pygame.display.flip()
                    if pressed1 or appuie:
                        try:
                            self.player.can_move = True
                        except:
                            print("",end="")
                        finally:
                            return True
                elif non_rect.collidepoint(pos2) or selecteur == 2 or back:
                    play_button = pygame.image.load('assets/play_button_mousing.png')
                    play_button = pygame.transform.scale(play_button,(abs(non_rect.w+30),abs(non_rect.h+20)))
                    play_button_rect = play_button.get_rect()
                    play_button_rect.x = non_rect.x-10
                    play_button_rect.y = non_rect.y-10
                    self.screen.blit(play_button,play_button_rect)
                    pygame.display.flip()
                    if pressed1 or appuie or back:
                        try:
                            self.player.can_move = True
                        except:
                            print(end="")
                        finally:
                            return False
                    
                
                            
        
        while not skip:
            for event in pygame.event.get():
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_SPACE:
                        skip = True
                elif event.type == pygame.JOYBUTTONDOWN:
                    if event.button == 0:
                        skip = True
        try:
            self.player.can_move = True
        except:
            print(end="")



