###########################
#                         #
#        PygameRPG        #
#      Romain Lafosse     #
#                         #
#        Python 3.7.7     #
#        Thonny 3.2.7     #
#                         #
###########################
import pygame,random,time
from boss import Boss

class Projectile(pygame.sprite.Sprite):
    def __init__(self,game):
        """Initialise le projectile, avec son image, ses coordonnées, sa vitesse, etc..."""
        super().__init__()
        self.game = game
        self.pos = self.game.boss.pos
        if self.pos == "right":
            self.image = pygame.image.load('assets//magmatown//into_magma_castle//fireball.png')
        elif self.game.boss.pos == "left":
            self.image = pygame.image.load('assets//magmatown//into_magma_castle//fireball_left.png')
        self.image = pygame.transform.scale(self.image,(60,60))
        self.rect = self.image.get_rect()
        self.rect.y = 450
        self.speed = 37
        self.attack = self.game.boss.attack
    
    def forward(self):
        """Fait avancer le projectile suivant la direction du boss au moment du tir"""
        #le déplacement ne se fait que si ya pas de joueur
        if self.pos == "right":
            self.rect.x += self.speed
        elif self.pos == "left":
            self.rect.x -= self.speed
        else:
            if self.rect.x<self.game.player.rect.x:
                self.game.player.damage(self.attack,'')
            else:
                self.game.player.damage(self.attack,'_left')
    def remove(self):
        """Supprime le projectile de l'écran"""
        self.game.all_projectiles.remove(self)
        