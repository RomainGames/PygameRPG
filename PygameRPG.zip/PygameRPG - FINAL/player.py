###########################
#                         #
#        PygameRPG        #
#      Romain Lafosse     #
#                         #
#        Python 3.7.7     #
#        Thonny 3.2.7     #
#                         #
###########################
import pygame
import sqlite3
import time
import ctypes




class Player(pygame.sprite.Sprite):
    """Class qui définit le joueur"""
    def __init__(self,screen,game,health,max_health,level,xp,xp_next_level,attack,speed,x):
        """Avec toutes les données demandés, le joueur est créé. Cela permet de charger la sauvegarde"""
        super().__init__()
        self.game = game
        self.screen = screen
        self.max_health = int(max_health) #Vie max de base = 10
        self.health = int(float(health))
        self.level = int(level) #Niveau de base = 1
        self.xp = int(xp)
        self.xp_next_level = int(xp_next_level)
        self.attack = int(attack) #Attaque de base = 2
        self.speed = int(speed)
        self.attack_speed = 0.01
        self.image = pygame.image.load('assets\\player.png')
        self.image = pygame.transform.scale(self.image,(int((100*self.screen.get_width()/1080)),int((200*self.screen.get_height()/720))))
        self.rect = self.image.get_rect()
        self.rect.x = int(x)
        self.rect.y = 350
        self.walkage = 1
        self.can_move = True

    def damage(self,amount,direction,projectile = False):
        """Inflige des dégats au joueur. Si il meurt, il est renvoyé au menu principal"""
        #infliger dégats
        if not(self.game.cant_damage):
            self.health -= amount
            print("AÏE")
            if not projectile:
                if direction == '_left' and self.rect.x < 1040:
                    self.rect.x -= 50
                elif self.rect.x > -10:
                    self.rect.x += 75
            
            self.game.set_vibration(0, 1, 1)
            time.sleep(0.05)
            self.game.set_vibration(0,0,0)

            #Vérifier si il est mort
            if self.health <=0:
                print("mort")

    def left(self):
        """Fait avancer le joueur vers la gauche"""
        if self.walkage <5:
            self.image = pygame.image.load('assets\\player_walking_1_left.png')
            self.image = pygame.transform.scale(self.image,(int((100*self.screen.get_width()/1080)),int((200*self.screen.get_height()/720))))
            self.rect.x -= self.speed
            self.walkage += 1
        elif self.walkage <=10:
            self.image = pygame.image.load('assets\\player_walking_2_left.png')
            self.image = pygame.transform.scale(self.image,(int((100*self.screen.get_width()/1080)),int((200*self.screen.get_height()/720))))
            self.rect.x -= self.speed
            self.walkage += 1
        else:
            self.walkage = 1
            self.rect.x -= self.speed
            self.image = pygame.image.load('assets\\player_walking_1_left.png')
            self.image = pygame.transform.scale(self.image,(int((100*self.screen.get_width()/1080)),int((200*self.screen.get_height()/720))))

    def right(self):
        """Fait avancer le joueur vers la droite"""
        if self.walkage <5:
            self.image = pygame.image.load('assets\\player_walking_1.png')
            self.image = pygame.transform.scale(self.image,(int((100*self.screen.get_width()/1080)),int((200*self.screen.get_height()/720))))
            self.rect.x+=self.speed
            self.walkage += 1
        elif self.walkage <=10:
            self.image = pygame.image.load('assets\\player_walking_2.png')
            self.image = pygame.transform.scale(self.image,(int((100*self.screen.get_width()/1080)),int((200*self.screen.get_height()/720))))
            self.rect.x+=self.speed
            self.walkage +=1
        else:
            self.walkage = 1
            self.rect.x+=self.speed
            self.image = pygame.image.load('assets\\player_walking_1.png')
            self.image = pygame.transform.scale(self.image,(int((100*self.screen.get_width()/1080)),int((200*self.screen.get_height()/720))))
        """self.screen.blit(self.game.background, self.game.background_rect)
        self.screen.blit(self.game.chemin, self.game.chemin_rect)
        self.screen.blit(self.image, self.rect)"""

    def update_health_bar(self, surface):
        """Met à jour la barre de vie et la barre d'xp du joueur, tout en affichant son niveau"""
        #dessiner barre de vie
        pygame.draw.rect(surface,(172,9,9),[self.rect.x+5, self.rect.y, 100, 10])
        pygame.draw.rect(surface, (111,210,46), [self.rect.x+5, self.rect.y, (self.health/self.max_health)*100, 10])
        pygame.draw.rect(surface,(8,65,125),[self.rect.x+5, self.rect.y+20, 100, 10])
        pygame.draw.rect(surface, (11,112,220), [self.rect.x+5, self.rect.y+20, (self.xp/self.xp_next_level)*100, 10])
        font=pygame.font.Font(None, 16)
        lvl = font.render("Lv."+str(self.level),1,self.game.color.black())
        lvl_rect = lvl.get_rect()
        lvl_rect.x = self.rect.x + 112
        lvl_rect.y = self.rect.y + 20
        self.screen.blit(lvl,lvl_rect)
    def heal(self):
        """Restaure entièrement la vie du joueur"""
        self.health = self.max_health
        self.game.message(ligne1="Votre vie a entièrement été restauré")
     
    def next_level(self):
        """Fait monter d'un niveau le joueur"""
        if self.xp >= self.xp_next_level:
            self.level += 1
            self.game.message(ligne1="Vous montez d'un niveau !",ligne2="Vous êtes maintenant niveau "+str(self.level))
            self.attack += 0.5
            self.game.message(ligne1="Votre attaque passe à "+str(self.attack))
            if self.level%5==0:
                self.speed += 1
                self.game.message(ligne1="Votre vitesse passe à "+str(self.speed))
            self.max_health += 2
            self.game.message(ligne1="Votre vie maximale passe à "+str(self.max_health))
            self.heal()
            self.xp = abs(self.xp_next_level-self.xp)
            self.xp_next_level = int(self.xp_next_level*1.20)
            self.game.message(ligne1="Il vous faut maintenant "+str(self.xp_next_level)+" d'XP",ligne2 = "pour passer au niveau suivant")
        




