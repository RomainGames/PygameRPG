###########################
#                         #
#        PygameRPG        #
#      Romain Lafosse     #
#                         #
#        Python 3.7.7     #
#        Thonny 3.2.7     #
#                         #
###########################

import pygame,random,time

class Boss(pygame.sprite.Sprite):
    """Class qui définit le boss du jeu """
    def __init__(self,screen,game):
        """ Initialisation du boss, avec son image, ses points de vie etc..."""
        super().__init__()
        self.game = game
        self.screen = screen
        self.level = "???"
        self.health = 500
        self.max_health = 500
        self.attack = 20
        self.speed = "???"
        self.pos = "left"
        self.image = pygame.image.load('assets//magmatown//into_magma_castle//princess_left.png')
        self.image = pygame.transform.scale(self.image,(100,200))
        self.rect = self.image.get_rect()
        self.rect.y = 350
        self.rect.x = 800
        self.xp = 5000
        self.can_move = True
        self.pt2 = False
    
    def inversion(self):
        """Inverse l'image du boss"""
        if self.pos == "right":
            self.image = pygame.image.load('assets//magmatown//into_magma_castle//princess_left.png')
            self.image = pygame.transform.scale(self.image,(100,200))
            self.rect = self.image.get_rect()
            self.rect.y = 350
            self.pos = "left"
        elif self.pos == "left":
            self.image = pygame.image.load('assets//magmatown//into_magma_castle//princess.png')
            self.image = pygame.transform.scale(self.image,(100,200))
            self.rect = self.image.get_rect()
            self.rect.y = 350
            self.pos = "right"
            
    def update_health_bar(self, surface):
        """Met à jour la barre de vie du boss"""
        #dessiner barre de vie
        pygame.draw.rect(surface,(172,9,9),[20,100, 900, 20])
        pygame.draw.rect(surface, (111,210,46), [20,100, (self.health/self.max_health)*900, 20])
    
    def update_health_bar_2(self,surface):
        """Met à jour la deuxième barre de vie du boss pour sa deuxième phase"""
        pygame.draw.rect(surface,(172,9,9),[self.rect.x+5, self.rect.y, 100, 10])
        pygame.draw.rect(surface, (111,210,46), [self.rect.x+5, self.rect.y, (self.health/self.max_health)*100, 10])
    
    def damage(self,amount):
        """Inflige des dégats au boss, et met un message si ses points de vie atteignent 0"""
        #infliger dégats
        self.health -= amount
        #Vérifier si il est mort
        if self.health <=0 and not(self.pt2):
            time.sleep(0.1)
            self.game.message(ligne1="Bon, tu m'as battu.",speaker = "Princesse de Magmatown",speaker_color = self.game.color.boss_color())
            self.game.message(ligne1="Je respecte toujours ma parole,",ligne2="je vais libérer les soldats.",speaker = "Princesse de Magmatown",speaker_color = self.game.color.boss_color())
            self.game.message(ligne1="Mais, je reviendrais...",speaker = "Princesse de Magmatown",speaker_color = self.game.color.boss_color())
            self.game.message(ligne1="Vous avez battu la Princesse de Magmatown !")
            self.game.message(ligne1="Vous gagnez 1000 d'expériences")
            self.game.screen.blit(self.game.background,self.game.background_rect)
            self.game.screen.blit(self.game.player.image,self.game.player.rect)
            self.game.screen.blit(self.image,self.rect)
            self.game;all_monsters = pygame.sprite.Group()
            self.game.player.xp += 1000
            self.game.in_boss_fight = False
            for i in range(10):
                self.game.player.next_level() #Vérifier si il doit passer un niveau, sinon il devra attendre la fin de tous les messages
            time.sleep(3)
            self.game.message(ligne1="Je reviendrai...",ligne2 = "MAINTENANT !",speaker = "Princesse de Magmatown",speaker_color = self.game.color.boss_color())
            self.pt2 = True
            self.become_monster()
        elif self.health <= 0 and self.pt2:
            self.game.message(ligne1="J'avoue ma défaite",ligne2="Tu es bien trop puissant pour moi",speaker = "Princesse de Magmatown",speaker_color = self.game.color.boss_color())
            self.game.message(ligne1="Je ne reviendrai plus.",speaker = "Princesse de Magmatown",speaker_color = self.game.color.boss_color())
            self.game.message(ligne1="Merci pour ce combat.",speaker = "Princesse de Magmatown",speaker_color = self.game.color.boss_color())
            self.game.message(ligne1="Vous avez (réellement) battu la Princesse de Magmatown !")
            self.game.message(ligne1="Vous gagnez 2000 d'expériences")
            self.game.player.xp += 2000
            self.game.cant_castle = False
            self.game.cant_transition = False
            self.game.cant_save = False
            self.game.in_boss_fight = False
            self.game.in_attack = False
            self.game.boss_already_fight = True
            self.pt2 = False
            
            
    
    def become_monster(self):
        """ Création de la deuxième phase du boss, dans laquelle celui-ci prend les caractéristiques d'un monstre."""
        self.level = 150
        self.health = 10+self.level
        self.max_health = 10+self.level
        self.attack = 15
        self.speed = 4+(self.level//5)
        if self.pos == "right":
            self.inversion()
            self.rect.x = 800
            self.speed = -self.speed
        elif self.pos == "left":
            self.inversion()
            self.rect.x = 10
    
    def forward(self):
        """Fait avancer le boss"""
        self.rect.x += self.speed
        
        
        
        
        
        
        

    
    
        
            