###########################
#                         #
#        PygameRPG        #
#      Romain Lafosse     #
#                         #
#        Python 3.7.7     #
#        Thonny 3.2.7     #
#                         #
###########################
import sqlite3
import pygame

class Save():
    """Permet la sauvegarde du jeu"""
    def __init__(self,game):
        """initialise la class, avec la lecture de la base de donnée regroupant certaines données en cas de réinitialisation"""
        self.game = game
        conn = sqlite3.connect('assets/player.db')
        cursor = conn.cursor()
        cursor.execute("""SELECT id,max_health,level,attack,speed,speed_attack,xp_next_level,xp FROM Start_Information""")
        info = cursor.fetchone()
        self.save_name_1 = ""
        self.save_name_2 = ""
        self.save_name_3 = ""
        self.max_health = info[1] #Vie max de base = 10
        self.health = self.max_health
        self.level = info[2] #Niveau de base = 1
        self.xp = info[7]
        self.xp_next_level = info[6]
        self.attack = info[3] #Attaque de base = 2
        self.speed = info[4]+10
        self.attack_speed = info[5]/50
        self.x = 100 #Variable en brut, définissant le premier point d'apparition
        self.zone = 1
        self.lieu = "Forest"
    
    def modif_bd(self,health,max_health,level,attack,speed,zone,lieu,x,xp_next,xp,id_save,is_save,tuto,monster_spawn,first_time_cinematique,princess_quest,princess_pass,mini_boss_fight,boss_already_fight,last_cinematique,name = None,message=False):
        """Modifie la base de donnée, avec une clé primaire défini par l'utilisateur, et prenant en compte toutes les variables de la base de donnée
            Affiche "Sauvegarde effectué avec succès" si elle est fonctionnel, sinon, elle affiche l'erreur
        """
        
        try:
            sqliteConnection = sqlite3.connect('save.db')
            cursor = sqliteConnection.cursor()
            if name == None:
                name = self.save_name
            sql_update_query = """UPDATE save_information SET player_health = ?, player_max_health = ?,
                player_level = ?, player_attack = ?, player_speed = ?, player_zone = ?, player_lieu = ?,
                player_x = ?, player_xp_next_level = ?,player_xp = ?,is_save = ?, tuto = ?, monster_can_spawn = ?, save_name = ?,first_time_cinematique = ?, princess_quest = ?, princess_pass = ?,mini_boss_fight = ?, boss_already_fight = ?, last_cinematique = ? WHERE id = ?"""
            sql_update_data = (health,max_health,level,attack,speed,zone,lieu,x,xp_next,xp,is_save,tuto,monster_spawn,name,first_time_cinematique,princess_quest,princess_pass,mini_boss_fight,boss_already_fight,last_cinematique,id_save)
            cursor.execute(sql_update_query,sql_update_data)
            sqliteConnection.commit()
            if message:
                self.game.message("Sauvegarde effectué avec succès")
            cursor.close()

        except sqlite3.Error as error:
            print("Sauvegarde échoué",error)
        finally:
            if sqliteConnection:
                sqliteConnection.close()
    
    def load(self,id_save):
        """Charge une sauvegarde, avec toutes ses variables"""
        self.id = id_save
        id_save = tuple(str(id_save))
        conn = sqlite3.connect('save.db')
        cursor = conn.cursor()
        cursor.execute("""SELECT player_health,player_max_health,player_level,player_attack,player_speed,player_zone,player_lieu,player_x,player_xp_next_level,player_xp,tuto,monster_can_spawn,save_name,first_time_cinematique,princess_quest,princess_pass,mini_boss_fight,boss_already_fight,last_cinematique FROM save_information WHERE id = ?""",id_save)
        info = cursor.fetchone()
        return info[0],info[1],info[2],info[3],info[4],info[5],info[6],info[7],info[8],info[9],info[10],info[11],info[12],info[13],info[14],info[15],info[16],info[17],info[18]
        
    
    def sauvegarder(self,id_save):
        """Sauvegarde le jeu, en prenant toutes les variables depuis la class Game"""
        print(id_save)
        self.modif_bd(self.game.player.health,self.game.player.max_health,self.game.player.level,
                      self.game.player.attack,self.game.player.speed,self.game.zone,self.game.lieu,self.game.player.rect.x,self.game.player.xp_next_level,
                      self.game.player.xp,id_save,1,self.game.tuto,self.game.monster_can_spawn,self.game.first_time_cinematique,self.game.princess_quest,self.game.princess_pass,self.game.mini_boss_fight,self.game.boss_already_fight,self.game.last_cinematique,message = True)
    
    def new_game(self,id_save):
        """Réinitialise une sauvegarde, en redonnant les données de base"""
        self.save_name = ""
        if self.is_new_game(id_save):
            self.save_name = self.game.message(ligne1 = "Veuillez donnez un nom à la sauvegarde", ask = True)
        self.modif_bd(self.health,self.health,self.level,self.attack,self.speed,self.zone,self.lieu,self.x,self.xp_next_level,self.xp,id_save,0,False,False,True,False,False,False,False,False,name = self.save_name)
    
    def is_new_game(self,id_save):
        """Vérifie, grâce à une variable dans la base donnée, si la sauvegarde est 'vide' ou non"""
        conn = sqlite3.connect('save.db')
        cursor = conn.cursor()
        cursor.execute("""SELECT is_save FROM save_information WHERE id = ?""",str(id_save))
        info = cursor.fetchone()
        if bool(info[0]):
            return False
        else:
            return True
        
        