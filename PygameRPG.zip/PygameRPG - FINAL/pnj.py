###########################
#                         #
#        PygameRPG        #
#      Romain Lafosse     #
#                         #
#        Python 3.7.7     #
#        Thonny 3.2.7     #
#                         #
###########################
import pygame
import sqlite3
import time
import ctypes




class Pnj(pygame.sprite.Sprite):
    """Définit les pnj (Personnage Non-Joueur) du jeu"""
    def __init__(self,zone,perso,x,pos,screen):
        super().__init__()
        self.screen = screen
        self.pos = pos
        self.perso = perso
        if self.pos == 'left':
            self.perso = perso + '_left'
        if zone == 'into_castle':
            self.image = pygame.image.load('assets/castle/into_castle/'+self.perso+'.png')
        self.image = pygame.transform.scale(self.image,(int((100*self.screen.get_width()/1080)),int((200*self.screen.get_height()/720))))
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = 350
    
    def inversion(self):
        """Inverse l'image du pnj"""
        if self.pos == 'left':
            self.image = pygame.image.load('assets/castle/into_castle/'+self.perso+'.png')
            self.image = pygame.transform.scale(self.image,(int((100*self.screen.get_width()/1080)),int((200*self.screen.get_height()/720))))
            self.pos = 'right'
        elif self.pos == 'right':
            self.image = pygame.image.load('assets/castle/into_castle/'+self.perso+'_left.png')
            self.image = pygame.transform.scale(self.image,(int((100*self.screen.get_width()/1080)),int((200*self.screen.get_height()/720))))
            self.pos = 'left'
        
    