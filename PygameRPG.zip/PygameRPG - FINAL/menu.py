###########################
#                         #
#        PygameRPG        #
#      Romain Lafosse     #
#                         #
#        Python 3.7.7     #
#        Thonny 3.2.7     #
#                         #
###########################
import pygame


class Menu():
    """Définit le menu du jeu"""
    def __init__(self,game):
        self.game = game
    
    
    def quit_game(self):
        if self.game.message(ligne1="Êtes-vous sûr ? Votre progression n'est",ligne2="pas sauvegarder",choice = True):
            quit()
    
    def save(self):
        self.game.save.sauvegarder(self.game.save.id)
    
    def lancer_menu(self):
        """Fonctionne de la même manière que le menu principal, mais avec un bouton sauvegarder, et un bouton quitter"""
        menu = True
        back = False
        manette_used = False
        selecteur = 0
        pos = pygame.mouse.get_pos
        appuie = False
        while menu:
            self.game.screen.blit(self.game.background,self.game.background_rect)
            font=pygame.font.Font(None, 100)
            menu = font.render("Menu",1,(255,255,255))
            self.game.screen.blit(menu, (300, 30))
            font2 = pygame.font.Font(None,70)
            save = font2.render("Sauvegarder",1,self.game.color.black())
            quit_game = font2.render("Quitter le jeu",1,self.game.color.black())
            save_rect = save.get_rect()
            quit_game_rect = quit_game.get_rect()
            save_rect.x = 300
            save_rect.y = 200
            quit_game_rect.x = 300
            quit_game_rect.y = 400
            self.game.screen.blit(save,save_rect)
            self.game.screen.blit(quit_game,quit_game_rect)
            if self.game.cant_save:
                croix = pygame.image.load('assets/croix.png')
                croix = pygame.transform.scale(croix,(abs(save_rect.w+30),abs(save_rect.h+20)))
                croix_rect = croix.get_rect()
                croix_rect.x = save_rect.x-10
                croix_rect.y = save_rect.y-10
                self.game.screen.blit(croix,croix_rect)
            pos2 = pygame.mouse.get_pos()
            if pos != pos2:
                pos = pos2
                manette_used = False
            pressed1, pressed2, pressed3 = pygame.mouse.get_pressed()
            for event in pygame.event.get():
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        menu = False
                elif event.type == pygame.JOYBUTTONDOWN:
                    if event.button == 7:
                        menu = False
                if pygame.joystick.get_init():
                    if event.type == pygame.JOYBUTTONDOWN:
                        if event.button == 0:
                            appuie = True
                        elif event.button == 1:
                            back = True
                    elif event.type == pygame.JOYBUTTONUP:
                        if event.button == 0:
                            appuie = False
                        elif event.button == 1:
                            back = False
                    elif event.type == pygame.JOYHATMOTION:
                        if manette_used == False:
                            manette_used = True
                            selecteur = 1
                        elif event.value[1] != 0:
                            if event.value[1] == 1 and selecteur<1: #Haut
                                selecteur += 1
                            elif event.value[1] == -1 and selecteur>0: #Bas
                                selecteur -= 1
                    elif event.type == pygame.JOYAXISMOTION:
                        if not manette_used:
                            manette_used = True
                        elif event.axis == 1 and event.value > 0.5:
                            if selecteur>0:
                                selecteur -= 1
                        elif event.axis == 1 and event.value < -0.5:
                            if selecteur<1:
                                selecteur += 1
                
                else:
                    pass
            if back:
                menu = False
            if (quit_game_rect.collidepoint(pos2) and not(manette_used)) or (selecteur == 0 and manette_used):
                play_button = pygame.image.load('assets/play_button_mousing.png')
                play_button = pygame.transform.scale(play_button,(abs(quit_game_rect.w+30),abs(quit_game_rect.h+20)))
                play_button_rect = play_button.get_rect()
                play_button_rect.x = quit_game_rect.x-10
                play_button_rect.y = quit_game_rect.y-10
                self.game.screen.blit(play_button,play_button_rect)
                if pressed1 or appuie:
                    self.quit_game()
            elif (save_rect.collidepoint(pos2) and not(manette_used)) or (selecteur == 1 and manette_used):
                play_button = pygame.image.load('assets/play_button_mousing.png')
                play_button = pygame.transform.scale(play_button,(abs(save_rect.w+30),abs(save_rect.h+20)))
                play_button_rect = play_button.get_rect()
                play_button_rect.x = save_rect.x-10
                play_button_rect.y = save_rect.y-10
                self.game.screen.blit(play_button,play_button_rect)
                if pressed1 or appuie:
                    if not(self.game.cant_save):
                        self.save()
                        menu = False
                    else:
                        self.game.message(ligne1="Vous ne pouvez pas sauvegarder")
            pygame.display.flip()
        