###########################
#                         #
#        PygameRPG        #
#      Romain Lafosse     #
#                         #
#        Python 3.7.7     #
#        Thonny 3.2.7     #
#                         #
#  Dernier Test effectué: #
#    10/05/2021 12:30     #
#                         #
###########################

""" Ce fichier est le principal du jeu
    Lancez ce fichier pour lancer le jeu"""

############################
"""Liste des Modules importés"""
from tkinter import *
from tkinter.ttk import *
import pygame, time
from game import Game
import random
import sqlite3
############################


debug_mod = True #Active ou désactive le debug mod
"""Le debug mod ajoute des fonctionnalités pour les développeurs
1) En appuyant sur "m" du clavier, un monstre apparait au coordonnée x=600 (le reste est normal)
2) En appuyant sur "c" du clavier, nous pouvons entrer une commande
"""



lancement = False #Variable qui vérifie si le jeu est lancé


############################################################
""" Définition de la fenêtre de jeu """
pygame.display.set_caption("Python RPG") #Le titre
pygame.init() #L'initialisation de la fenêtre
screen=pygame.display.set_mode((1080,720)) #La taille
icon =  pygame.image.load("assets//game_icon.ico") #L'import de l'icône
pygame.display.set_icon(icon) #La mise en place de l'icône
###########################################################


lancement = True



end_zone = False
tuto = True


def end():
    """ Fonction qui permet d'arrêter le jeu """
    pygame.quit()
    print("Fermeture du jeu")
    quit()

#####################################################
"""Mise en place de la manette, si il y en a une"""
nb_joysticks = pygame.joystick.get_count()
if nb_joysticks > 0:
    mon_joystick = pygame.joystick.Joystick(0)
    mon_joystick.init()



def attack(direction):
    """ Fonction qui permet au joueur d'attaquer, celle-ci se lance lorsque le joueur choissit d'attaquer"""
    global in_attack
    global first_time_cinematique
    global nb_attack
    global attente
    
    if attente <=0:
        deja_attaque = False #Variable pour évitez de blesser le monstre plusieurs fois en une attaque
    
        #Vérification de la direction
        if direction == 'right':
            direction=''
        else:
            direction = '_left'
            game.player.rect.x -=27
        x = game.player.rect.x
        #Boucle pour afficher les 6 différentes étapes de l'animation d'attaque
        for i in range(1,6):
            ##############################################################
            """Affichage de tous ce qui doit être afficher sur l'écran"""
            screen.blit(game.background, game.background_rect)
            game.all_monsters.draw(screen)
            game.all_projectiles.draw(screen)
            game.player.update_health_bar(screen)
            if game.in_boss_fight:
                game.boss.update_health_bar(screen)
            if game.lieu == "castle" and game.zone == 3:
                screen.blit(game.guard.image,game.guard.rect)
            if game.zone == 'into_trone' and game.lieu == "into_castle" and not(game.first_time_cinematique):
                screen.blit(game.princess.image,game.princess.rect)
            elif game.zone == "into_trone" and not(game.boss_already_fight):
                screen.blit(game.boss.image,game.boss.rect)
            ##############################################################
            
            for monster in game.all_monsters: #Elle fait avancer tous les monstres, et met à jour leur barre de vie #Fonction qui fait avancer les monstres
                monster.update_health_bar(screen) #Fonction qui met à jour la barre de vie
        
            #Suivant l'état d'avancement de la boucle, on affiche les différentes images de l'animation de l'attaque
        
            game.player.image = pygame.image.load('assets\\player_attack\\player_attack_'+str(i)+direction+'.png')
            game.player.image = pygame.transform.scale(game.player.image,(125,200)) #On réadapte la taille de l'image
            game.player.rect = game.player.image.get_rect()
            game.player.rect.y = 350
            game.player.rect.x = x
            screen.blit(game.player.image, game.player.rect) #On affiche le joueur
            pygame.display.flip()
            if not deja_attaque: #Si il n'a pas déjà taper les monstres
                for monster in game.all_monsters: #Pour chaque monstre sur l'écran
                    if monster.rect.x>game.player.rect.x-100 and monster.rect.x<game.player.rect.x+90: #On detecte si le joueur tape le monstre
                        monster.damage(game.player.attack,direction) #On applique les dégats au monstres avec une fonction
                        if direction == '_left': #Suivant la direction de l'attaque, on applique les vibrations sur le côté gauche ou droit de la manette
                            game.set_vibration(0, 1, 0) #On fait vibrer le moteur gauche de la manette
                            time.sleep(0.2) #On attend
                            game.set_vibration(0,0,0) #On retire les vibrations
                        else:
                            game.set_vibration(0, 0, 1) #On fait vibrer le moteur droit de la manette
                            time.sleep(0.2)
                            game.set_vibration(0,0,0) #On enlève les vibrations
                    deja_attaque = True #On dit que nous avons déjà attaquer un monstre
                for projectile in game.all_projectiles: #Pour chaque projectile
                    if game.player.rect.left - 20 <= projectile.rect.right and game.player.rect.right + 20 >= projectile.rect.left: #Si le joueur en tape un
                        projectile.remove() #On le retire
                        if direction == '_left':
                            game.set_vibration(0, 1, 0)
                            time.sleep(0.2)
                            game.set_vibration(0,0,0)
                        else:
                            game.set_vibration(0, 0, 1)
                            time.sleep(0.2)
                            game.set_vibration(0,0,0)
                    
                if game.in_boss_fight: #Pour un boss 
                    if game.player.rect.left - 10 <= game.boss.rect.right and game.player.rect.right + 10 >= game.boss.rect.left:
                        game.boss.damage(game.player.attack) #On lui applique des dégats
                        deja_attack = True
                        global degats
                        degats = True
                elif game.boss.pt2:
                    if game.player.rect.left - 10 <= game.boss.rect.right and game.player.rect.right + 10 >= game.boss.rect.left:
                        game.boss.damage(game.player.attack)
                        deja_attack = True
            time.sleep(1/45) #On attend entre chaque animation d'attaque pour éviter des lags du jeu
    
        game.player.image = pygame.image.load('assets\\player'+direction+'.png') #On reprend le joueur de base
        game.player.image = pygame.transform.scale(game.player.image,(int((100*screen.get_width()/1080)),int((200*screen.get_height()/720)))) #On retransforme l'image dans les bonnes dimensions
        game.player.rect = game.player.image.get_rect()
        game.player.rect.y = 350
        game.player.rect.x = x
        attente = 10 - int((game.player.level/2)) #Logiquement, à partir du niveau 20, il n'y aura plus d'attente
        if direction == '_left': #Lorsque le joueur est orienté sur la gauche
            game.player.rect.x +=27 #Il faut modifier légèrement sa position, puisque le personnage n'est pas positionné de la même manière sur l'image

""" Il est très important d'agrandir l'image directement dans le jeu, pour avoir l'effet pixélisé"""

####################################
"""Définition de variable qui permette de savoir  si le joueur bouge, si il attaque, si il a déjà vu le chateau, ou qu'il a déjà essayé d'en sortir"""
is_moving_right = False
is_moving_left = False
in_attack = False
first_time_castle = True
premier_message_sortie_chateau = True
####################################

first_time_cinematique = True


def cinematique_princesse_chateau():
    """ Fonction de la cinématique du château de la forêt"""
    global first_time_cinematique
    game.player.can_move = False #On empèche le joueur de bouger
    #On affiche tout ce qui doit être affiché
    screen.blit(game.background, game.background_rect)
    screen.blit(game.princess.image, game.princess.rect)
    screen.blit(game.guard.image,game.guard.rect)
    screen.blit(game.player.image, game.player.rect)
    pygame.display.update()
    time.sleep(1)
    #Les messages affichés:
    game.message(ligne1="Nous ne pouvons pas l'attaquer, elle est bien trop puissante.",speaker="Guard",speaker_color=game.color.gray())
    game.message(ligne1="Nous n'avons plus le choix.",ligne2="Elle est une trop grande menace",speaker="Princesse",speaker_color=game.color.pink())
    game.message(ligne1="Madame, vous ne ferez que tuer tous",ligne2="nos hommes !",speaker="Guard",speaker_color=game.color.gray())
    game.message(ligne1="Je le sais bien.",speaker="Princesse",speaker_color=game.color.pink())
    game.message(ligne1="Pour l'instant, maintenez les positions.",ligne2="Nous devons réfléchir à une stratégie",speaker="Princesse",speaker_color=game.color.pink())
    game.message(ligne1="Bien Madame.",speaker="Guard",speaker_color=game.color.gray())
    game.guard.inversion() #On retourne le garde
    screen.blit(game.background, game.background_rect)
    screen.blit(game.princess.image, game.princess.rect)
    screen.blit(game.player.image, game.player.rect)
    screen.blit(game.guard.image,game.guard.rect)
    pygame.display.update()
    while game.guard.rect.x > -110:
        #On sort le garde de l'écran, petit à petit
        game.guard.rect.x -= 5
        screen.blit(game.background, game.background_rect)
        screen.blit(game.princess.image, game.princess.rect)
        screen.blit(game.player.image, game.player.rect)
        screen.blit(game.guard.image,game.guard.rect)
        pygame.display.update()
        time.sleep(1/60)
    #Suite de la cinématique
    game.message(ligne1="*soupir*",ligne2="A ce rythme, le Royaume ne va...",speaker="Princesse",speaker_color=game.color.pink())
    game.message(ligne1="Tiens ? Bonjour cher visiteur.",speaker="Princesse",speaker_color=game.color.pink())
    game.message(ligne1="...",speaker="Princesse",speaker_color=game.color.pink())
    #Un choix pour voir si le joueur veut aider la princesse, mais la conclusion est la même
    if game.message(ligne1="Voulez-vous bien nous aider ?",speaker="Princesse",speaker_color=game.color.pink(),choice = True):
        screen.blit(game.background, game.background_rect)
        screen.blit(game.princess.image, game.princess.rect)
        screen.blit(game.player.image, game.player.rect)
        screen.blit(game.guard.image,game.guard.rect)
        screen.blit(game.guard.image,game.guard.rect)
        pygame.display.update()
        game.message(ligne1="Parfait !",speaker="Princesse",speaker_color=game.color.pink())
    else:
        screen.blit(game.background, game.background_rect)
        screen.blit(game.princess.image, game.princess.rect)
        screen.blit(game.player.image, game.player.rect)
        screen.blit(game.guard.image,game.guard.rect)
        screen.blit(game.guard.image,game.guard.rect)
        pygame.display.update()
        game.message(ligne1="C'est un jeu, vous êtes obligé d'accepter")
        game.message(ligne1="Parfait !",speaker="Princesse",speaker_color=game.color.pink())
    game.message(ligne1="Vous n'êtes que niveau "+str(game.player.level)+".",ligne2="Revenez lorsque vous serez niveau 10.",speaker="Princesse",speaker_color=game.color.pink())
    game.message(ligne1="Il y a des monstres dans la forêt à l'extérieur.",ligne2="Vous atteindrez le niveau requis rapidement",speaker="Princesse",speaker_color=game.color.pink())
    #On fait en sorte que le joueur puisse marcher
    game.princess_quest = True
    game.player.can_move = True
    game.first_time_cinematique = False
    
    
game = Game(screen) #On crée l'objet Game
is_new = False
lancement = False
def prelancement():
    """Fonction du menu principal du jeu"""
    global lancement
    global is_new
    select_new = False
    select_continue = False
    lancement = False
    manette_used = False #Fonction qui vérifie si le joueur utilise la manette
    #On va ouvrir la base de donnée du jeu, pour voir si la musique doit être lancée
    conn = sqlite3.connect('game_info.db')
    cursor = conn.cursor()
    cursor.execute("""SELECT music FROM option WHERE id = ?""","1")
    info = cursor.fetchone()
    if info[0]==1:
        music = True
    else:
        music = False
    if music:
        pygame.mixer.music.load('assets\start_menu.ogg') #On trouve la musique
        pygame.mixer.music.play(-1) #On la lance en boucle (le -1 la fait répéter à l'infini)
    selecteur = 0 #Niveau du sélécteur
    pos2 = pygame.mouse.get_pos() #Position de la souris qui vérifie quelle ne bouge pas, si la manette est utilisé
    while not(lancement): #Tant que le jeu n'est pas lancé
        game.background = pygame.image.load('assets/neutral_background.png') #On affiche le fond d'écran
        game.background = pygame.transform.scale(game.background,(screen.get_width(),screen.get_height()))
        game.background_rect = game.background.get_rect()
        screen.blit(game.background,game.background_rect)
        font=pygame.font.Font(None, 40)
        texte_a_afficher = font.render("Bienvenue dans:",1,(0,0,0)) #On affiche les titres
        screen.blit(texte_a_afficher, (screen.get_width()/3+25, 20))
        font2=pygame.font.Font(None, 100)
        texte_a_afficher2 = font2.render("PygameRPG !",1,(0,0,0))
        screen.blit(texte_a_afficher2, (screen.get_width()/3-50, 60))
        new_game = pygame.image.load('assets/new_game.png')  #Les deux boutons Nouvelle et Continuer partie sont des images, donc on les affiche.
        new_game_rect = new_game.get_rect()
        new_game_rect.x = screen.get_width()/4
        new_game_rect.y = 200
        screen.blit(new_game,new_game_rect)
        continue_game = pygame.image.load('assets/continue_game.png')  
        continue_game_rect = continue_game.get_rect()
        continue_game_rect.x = screen.get_width()/4
        font=pygame.font.Font(None, 80)
        continue_game_rect.y = 300
        screen.blit(continue_game,continue_game_rect)
        option = font.render("Option",1,game.color.black()) #On écrit les autres options
        option_rect = option.get_rect()
        option_rect.x = screen.get_width()/3
        option_rect.y = 450
        screen.blit(option,option_rect)
        quitter = font.render("Quitter",1,game.color.black())
        quitter_rect = quitter.get_rect()
        quitter_rect.x = screen.get_width()/3
        quitter_rect.y = 600
        screen.blit(quitter,quitter_rect)
        appuie = False
        back = False
        for event in pygame.event.get(): #On va donc regarder si les boutons de la manette sont appuyés
            if pygame.joystick.get_init():
                if event.type == pygame.JOYBUTTONDOWN: #Si c'est le cas
                    if event.button == 0: #Si c'est le bouton croix, ou "A"
                        appuie = True #On dit que l'on appuie 
                    elif event.button == 1: #Si c'est le bouton rond, ou "B"
                        retour = True #On fait un retour
                elif event.type == pygame.JOYBUTTONDOWN: #Si les boutons sont relachés, on met false à ces variables
                    if event.button == 0:
                        appuie = False
                    elif event.button == 1:
                        retour = False
                elif event.type == pygame.JOYHATMOTION: #Si les flèches directionnels sont utilisés
                    if manette_used == False:
                        selecteur = 0
                        manette_used = True #On dit que le joueur utilise sa manette
                        
                    
                    elif event.value[1] != 0: #Si il appuie sur haut ou bas
                        if event.value[1] == 1 and selecteur >0: #Haut
                            selecteur -= 1 #On remonte dans les sélécteurs
                        elif event.value[1] == -1 and selecteur<3: #Bas
                            selecteur += 1 #On descend dans les sélecteurs
                            
            else:
                pass
        pos = pygame.mouse.get_pos() #On prend les coordonnées de la souris
        if manette_used:
            if pos != pos2: #Si on la bouge alors que l'on utilise la manette
                manette_used = False #On retire l'utilisation de la manette
                pos2 = pos
        pressed1, pressed2, pressed3 = pygame.mouse.get_pressed() #On regarde si les 3 boutons principaux de la souris sont appuyés


        """Ici, le principe est le même pour chaque bouton appuyé sur le menu. Voici donc l'explication complète"""
        if (new_game_rect.collidepoint(pos) and not(manette_used)) or (selecteur == 0 and manette_used): #Si une collision est faite entre le bouton et la souris, ou que le sélecteur est positionné dessus
            play_button = pygame.image.load('assets/play_button_mousing.png') #On récupère un rectangle (qui permet de montrer la selection)
            play_button = pygame.transform.scale(play_button,(abs(new_game_rect.w),abs(new_game_rect.h))) #On met cette image au dimension du bouton
            play_button_rect = play_button.get_rect()
            play_button_rect.x = new_game_rect.x #On lui met les mêmes coordonnées que le bouton
            play_button_rect.y = new_game_rect.y
            screen.blit(play_button,play_button_rect) #Et on l'affiche
            pos3 = pos2
            if pressed1 or appuie: #Si le joueur choisit d'appuyer ou de cliquer, on lance ce que le bouton est censé lancer (ici c'est les nouvelles parties)
                menu_new_game = True
                compteur = 0
                selecteur = 1
                while menu_new_game: #Tant que l'on reste dans ce menu
                    screen.blit(game.background,game.background_rect)
                    font2=pygame.font.Font(None, 40)
                    """Si les sauvegardes sont vides (on peut le vérifier grâce à une fonction qui lit la base de donnée)
                        on affiche qu'elle est vide. Sinon, on affiche son nom, et le niveau
                        Le joueur ne peut pas lancer une partie non-vide comme nouvelle partie
                    """
                        
                    if game.save.is_new_game(1):
                        Save_1 = font2.render("Savegarde 1: Aucune Donnée",1,game.color.black())
                        save_1_new = True
                    else:
                        conn = sqlite3.connect('save.db')
                        cursor = conn.cursor()
                        cursor.execute("""SELECT save_name, player_level FROM save_information WHERE id = ?""","1")
                        info = cursor.fetchone()
                        Save_1 = font2.render("Savegarde 1: "+str(info[0])+" - Lv."+str(info[1]),1,game.color.black())
                        save_1_new = False
                                            
                    if game.save.is_new_game(2):
                        Save_2 = font2.render("Savegarde 2: Aucune Donnée",1,game.color.black())
                        save_2_new = True
                    else:
                        conn = sqlite3.connect('save.db')
                        cursor = conn.cursor()
                        cursor.execute("""SELECT save_name, player_level FROM save_information WHERE id = ?""","2")
                        info = cursor.fetchone()
                        Save_2 = font2.render("Savegarde 2: "+str(info[0])+" - Lv."+str(info[1]),1,game.color.black())
                        save_2_new = False
                                            
                    if game.save.is_new_game(3):
                        Save_3 = font2.render("Savegarde 3: Aucune Donnée",1,game.color.black())
                        save_3_new = True
                    else:
                        conn = sqlite3.connect('save.db')
                        cursor = conn.cursor()
                        cursor.execute("""SELECT save_name, player_level FROM save_information WHERE id = ?""","3")
                        info = cursor.fetchone()
                        Save_3 = font2.render("Savegarde 3: "+str(info[0])+" - Lv."+str(info[1]),1,game.color.black())
                        save_3_new = False
                    retour = font2.render("Retour",1,game.color.black()) #Un bouton retour pour revenir au menu principal
                    delete = font2.render("Effacer",1,game.color.black()) #Un bouton pour supprimer les sauvegardes
                    appuie = False #Les mêmes variables pour la manette
                    back = False
                    for event in pygame.event.get():
                        if pygame.joystick.get_init():
                            if event.type == pygame.JOYBUTTONDOWN:
                                if event.button == 0:
                                    appuie = True
                                elif event.button == 1:
                                    back = True
                            elif event.type == pygame.JOYBUTTONDOWN:
                                if event.button == 0:
                                    appuie = False
                                elif event.button == 1:
                                    back = False
                            
                            if event.type == pygame.JOYHATMOTION:
                                if manette_used == False:
                                    manette_used = True
                                    selecteur = 1
                                """Si on atteint le bout du menu avec le selecteur, mais que l'on continue quand même, nous revenons au début (ou à la fin)"""
                                if event.value[1] != 0:
                                    if event.value[1] == 1 and selecteur>0: #Haut
                                        selecteur -= 1
                                    elif event.value[1] == 1 and selecteur == 0:
                                        selecteur = 4
                                    elif event.value[1] == -1 and selecteur<4: #Bas
                                        selecteur += 1
                                    elif event.value[1] == -1 and selecteur == 4:
                                        selecteur = 0
                                elif event.value[0] == -1 and selecteur == 3:
                                    selecteur += 1
                                elif event.value[0] == 1 and selecteur == 4:
                                    selecteur -= 1
                        else:
                            pass
                    Save_1_rect = Save_1.get_rect() #On récupère les informations de tous les textes, et on les affiches au bonnes coordonnées
                    Save_2_rect = Save_2.get_rect()
                    Save_3_rect = Save_3.get_rect()
                    retour_rect = retour.get_rect()
                    delete_rect = delete.get_rect()
                    Save_1_rect.x = Save_2_rect.x = Save_3_rect.x = screen.get_width()/4+5
                    Save_1_rect.y = 200
                    Save_2_rect.y = 400
                    Save_3_rect.y = 600
                    retour_rect.x = 50
                    retour_rect_y = 800
                    delete_rect.x = 20
                    delete_rect.y = 600
                    screen.blit(Save_1, Save_1_rect)
                    screen.blit(Save_2, Save_2_rect)
                    screen.blit(Save_3, Save_3_rect)
                    screen.blit(retour,retour_rect)
                    screen.blit(delete,delete_rect)
                    pos4 = pygame.mouse.get_pos()
                    if manette_used:
                        if pos4 != pos3:
                            pos3 = pos4
                            manette_used = False
                    pressed1, pressed2, pressed3 = pygame.mouse.get_pressed()
                    if (delete_rect.collidepoint(pos4) and compteur>5 and not(manette_used)) or (selecteur == 4 and manette_used):
                        play_button = pygame.image.load('assets/play_button_mousing.png')
                        play_button = pygame.transform.scale(play_button,(abs(delete_rect.w+30),abs(delete_rect.h+20)))
                        play_button_rect = play_button.get_rect()
                        play_button_rect.x = delete_rect.x-10
                        play_button_rect.y = delete_rect.y-10
                        screen.blit(play_button,play_button_rect)
                        pos = pygame.mouse.get_pos()
                        if pressed1 or appuie:
                            """On réitère l'affichage des sauvegardes, mais en rouge cette fois-ci. Si on clique sur l'une des sauvegardes, on va donc avoir le choix de la supprimer"""
                            game.message(ligne1="Choissisez la sauvegarde que vous souhaitez supprimer")
                            choix = True
                            compteur=0
                            selecteur = -2
                            screen.blit(game.background,game.background_rect)
                            font2=pygame.font.Font(None, 40)
                            if game.save.is_new_game(1):
                                Save_1 = font2.render("Savegarde 1: Aucune Donnée",1,game.color.red())
                                save_1_new = True
                            else:
                                conn = sqlite3.connect('save.db')
                                cursor = conn.cursor()
                                cursor.execute("""SELECT save_name,player_level FROM save_information WHERE id = ?""","1")
                                info = cursor.fetchone()
                                Save_1 = font2.render("Savegarde 1: "+str(info[0])+" - Lv."+str(info[1]),1,game.color.red())
                                save_1_new = False
                                            
                            if game.save.is_new_game(2):
                                Save_2 = font2.render("Savegarde 2: Aucune Donnée",1,game.color.red())
                                save_2_new = True
                            else:
                                conn = sqlite3.connect('save.db')
                                cursor = conn.cursor()
                                cursor.execute("""SELECT save_name,player_level FROM save_information WHERE id = ?""","2")
                                info = cursor.fetchone()
                                Save_2 = font2.render("Savegarde 2: "+str(info[0])+" - Lv."+str(info[1]),1,game.color.red())
                                save_2_new = False
                                            
                            if game.save.is_new_game(3):
                                Save_3 = font2.render("Savegarde 3: Aucune Donnée",1,game.color.red())
                                save_3_new = True
                            else:
                                conn = sqlite3.connect('save.db')
                                cursor = conn.cursor()
                                cursor.execute("""SELECT save_name,player_level FROM save_information WHERE id = ?""","3")
                                info = cursor.fetchone()
                                Save_3 = font2.render("Savegarde 3: "+str(info[0])+" - Lv."+str(info[1]),1,game.color.red())
                                save_3_new = False
                            selecteur = 0
                            appuie = False
                            back = False
                            while choix:
                                screen.blit(game.background,game.background_rect)
                                screen.blit(Save_1, Save_1_rect)
                                screen.blit(Save_2, Save_2_rect)
                                screen.blit(Save_3, Save_3_rect)
                                screen.blit(retour,retour_rect)

                                for event in pygame.event.get():
                                    if manette_used == True and selecteur == -2:
                                        selecteur = 1
                                    if pygame.joystick.get_init():
                                        if event.type == pygame.JOYBUTTONDOWN:
                                            if event.button == 0:
                                                appuie = True
                                            elif event.button == 1:
                                                back = True
                                        elif event.type == pygame.JOYBUTTONUP:
                                            if event.button == 0:
                                                appuie = False
                                            elif event.button == 1:
                                                back = False
                                        elif event.type == pygame.JOYHATMOTION:
                                            if manette_used == False:
                                                manette_used = True
                                                selecteur = 1
                                            elif event.value[1] != 0:
                                                if event.value[1] == 1 and selecteur>0: #Haut
                                                    selecteur -= 1
                                                elif event.value[1] == -1 and selecteur<3: #Bas
                                                    selecteur += 1
                                    else:
                                        pass
                                pos2 = pygame.mouse.get_pos()
                                if pos2 != pos and manette_used:
                                    pos2 = pos
                                    manette_used == False
                                    selecteur = -2
                                pressed1, pressed2, pressed3 = pygame.mouse.get_pressed()
                                if (Save_1_rect.collidepoint(pos2) and compteur > 5) or (selecteur == 1 and manette_used):
                                    play_button = pygame.image.load('assets/play_button_mousing.png')
                                    play_button = pygame.transform.scale(play_button,(abs(Save_1_rect.w+30),abs(Save_1_rect.h+20)))
                                    play_button_rect = play_button.get_rect()
                                    play_button_rect.x = Save_1_rect.x-10
                                    play_button_rect.y = Save_1_rect.y-10
                                    screen.blit(play_button,play_button_rect)
                                    if (pressed1 or appuie) and not(save_1_new):
                                        if game.message(ligne1="Êtes-vous sûr de vouloir supprimer cette sauvegarde ?",choice = True):
                                            game.save.new_game(1)
                                            game.message(ligne1="Sauvegarde supprimé")
                                            choix = False
                                            compteur = 0
                                            if music:
                                                pygame.mixer.music.load('assets\start_menu.ogg')
                                                pygame.mixer.music.play(-1)
                                        else:
                                            compteur = 0
                                    elif pressed1:
                                        game.message(ligne1="Cette sauvegarde ne contient pas de données")
                                        if music:
                                            pygame.mixer.music.load('assets\start_menu.ogg')
                                            pygame.mixer.music.play(-1)
                                if (Save_2_rect.collidepoint(pos2) and compteur > 5 and not(manette_used)) or (selecteur == 2 and manette_used and compteur > 5):
                                    play_button = pygame.image.load('assets/play_button_mousing.png')
                                    play_button = pygame.transform.scale(play_button,(abs(Save_2_rect.w+30),abs(Save_2_rect.h+20)))
                                    play_button_rect = play_button.get_rect()
                                    play_button_rect.x = Save_2_rect.x-10
                                    play_button_rect.y = Save_2_rect.y-10
                                    screen.blit(play_button,play_button_rect)
                                    if (pressed1 or appuie) and not(save_2_new):
                                        if game.message(ligne1="Êtes-vous sûr de vouloir supprimer cette sauvegarde ?",choice = True):
                                            game.save.new_game(2)
                                            game.message(ligne1="Sauvegarde supprimé")
                                            choix = False
                                            if music:
                                                pygame.mixer.music.load('assets\start_menu.ogg')
                                                pygame.mixer.music.play(-1)
                                            compteur = 0
                                        else:
                                            compteur = 0
                                    elif pressed1:
                                        game.message(ligne1="Cette sauvegarde ne contient pas de données")
                                        if music:
                                            pygame.mixer.music.load('assets\start_menu.ogg')
                                            pygame.mixer.music.play(-1)
                                if (Save_3_rect.collidepoint(pos2) and compteur > 5 and not(manette_used)) or (selecteur == 3 and manette_used and compteur > 5):
                                    play_button = pygame.image.load('assets/play_button_mousing.png')
                                    play_button = pygame.transform.scale(play_button,(abs(Save_3_rect.w+30),abs(Save_3_rect.h+20)))
                                    play_button_rect = play_button.get_rect()
                                    play_button_rect.x = Save_3_rect.x-10
                                    play_button_rect.y = Save_3_rect.y-10
                                    screen.blit(play_button,play_button_rect)
                                    if (pressed1 or appuie) and not(save_3_new):
                                         if game.message(ligne1="Êtes-vous sûr de vouloir supprimer la 3ème sauvegarde ?",choice = True):
                                            game.save.new_game(3) #Pour supprimer la sauvegarde, on utilise la fonction dans save pour réinitialiser la sauvegarde
                                            game.message(ligne1="Sauvegarde supprimé")
                                            choix = False
                                            compteur = 0
                                            if music:
                                                pygame.mixer.music.load('assets\start_menu.ogg')
                                                pygame.mixer.music.play(-1)
                                         else:
                                            compteur = 0
                                            if music:
                                                pygame.mixer.music.load('assets\start_menu.ogg')
                                                pygame.mixer.music.play(-1)
                                    elif pressed1:
                                        game.message(ligne1="Cette sauvegarde ne contient pas de données")
                                        if music:
                                            pygame.mixer.music.load('assets\start_menu.ogg')
                                            pygame.mixer.music.play(-1)
                                if (retour_rect.collidepoint(pos2) and not(manette_used)) or back or (selecteur == 0 and manette_used and compteur > 5):
                                    play_button = pygame.image.load('assets/play_button_mousing.png')
                                    play_button = pygame.transform.scale(play_button,(abs(retour_rect.w+30),abs(retour_rect.h+20)))
                                    play_button_rect = play_button.get_rect()
                                    play_button_rect.x = retour_rect.x-10
                                    play_button_rect.y = retour_rect.y-10
                                    screen.blit(play_button,play_button_rect)
                                    if pressed1 or back or appuie:
                                        choix = False
                                        if game.save.is_new_game(1):
                                            Save_1 = font2.render("Savegarde 1: Aucune Donnée",1,game.color.black())
                                            save_1_new = True
                                        else:
                                            conn = sqlite3.connect('save.db')
                                            cursor = conn.cursor()
                                            cursor.execute("""SELECT save_name,player_level FROM save_information WHERE id = ?""","1")
                                            info = cursor.fetchone()
                                            Save_1 = font2.render("Savegarde 1: "+str(info[0])+" - Lv."+str(info[1]),1,game.color.black())
                                            save_1_new = False
                                            
                                        if game.save.is_new_game(2):
                                            Save_2 = font2.render("Savegarde 2: Aucune Donnée",1,game.color.black())
                                            save_2_new = True
                                        else:
                                            conn = sqlite3.connect('save.db')
                                            cursor = conn.cursor()
                                            cursor.execute("""SELECT save_name,player_level FROM save_information WHERE id = ?""","2")
                                            info = cursor.fetchone()
                                            Save_2 = font2.render("Savegarde 2: "+str(info[0])+" - Lv."+str(info[1]),1,game.color.black())
                                            save_2_new = False
                                            
                                        if game.save.is_new_game(3):
                                            Save_3 = font2.render("Savegarde 3: Aucune Donnée",1,game.color.black())
                                            save_3_new = True
                                        else:
                                            conn = sqlite3.connect('save.db')
                                            cursor = conn.cursor()
                                            cursor.execute("""SELECT save_name,player_level FROM save_information WHERE id = ?""","3")
                                            info = cursor.fetchone()
                                            Save_3 = font2.render("Savegarde 3: "+str(info[0])+" - Lv."+str(info[1]),1,game.color.black())
                                            save_3_new = False
                                        selecteur = -80
                                        back = False
                                if choix == False:
                                    if game.save.is_new_game(1):
                                        Save_1 = font2.render("Savegarde 1: Aucune Donnée",1,game.color.black())
                                        save_1_new = True
                                    else:
                                        conn = sqlite3.connect('save.db')
                                        cursor = conn.cursor()
                                        cursor.execute("""SELECT save_name,player_level FROM save_information WHERE id = ?""","1")
                                        info = cursor.fetchone()
                                        Save_1 = font2.render("Savegarde 1: "+str(info[0])+" - Lv."+str(info[1]),1,game.color.black())
                                        save_1_new = False
                                            
                                    if game.save.is_new_game(2):
                                        Save_2 = font2.render("Savegarde 2: Aucune Donnée",1,game.color.black())
                                        save_2_new = True
                                    else:
                                        conn = sqlite3.connect('save.db')
                                        cursor = conn.cursor()
                                        cursor.execute("""SELECT save_name,player_level FROM save_information WHERE id = ?""","2")
                                        info = cursor.fetchone()
                                        Save_2 = font2.render("Savegarde 2: "+str(info[0])+" - Lv."+str(info[1]),1,game.color.black())
                                        save_2_new = False
                                            
                                    if game.save.is_new_game(3):
                                        Save_3 = font2.render("Savegarde 3: Aucune Donnée",1,game.color.black())
                                        save_3_new = True
                                    else:
                                        conn = sqlite3.connect('save.db')
                                        cursor = conn.cursor()
                                        cursor.execute("""SELECT save_name,player_level FROM save_information WHERE id = ?""","3")
                                        info = cursor.fetchone()
                                        Save_3 = font2.render("Savegarde 3: "+str(info[0])+" - Lv."+str(info[1]),1,game.color.black())
                                        save_3_new = False
                                    selecteur = -80
                                    compteur = 0
                                compteur +=1
                                pygame.display.flip()
                                time.sleep(1/60)
                                
                    if (Save_1_rect.collidepoint(pos4) and compteur>5 and not(manette_used)) or (selecteur == 1 and manette_used and compteur > 5):
                        play_button = pygame.image.load('assets/play_button_mousing.png')
                        play_button = pygame.transform.scale(play_button,(abs(Save_1_rect.w+30),abs(Save_1_rect.h+20)))
                        play_button_rect = play_button.get_rect()
                        play_button_rect.x = Save_1_rect.x-10
                        play_button_rect.y = Save_1_rect.y-10
                        screen.blit(play_button,play_button_rect)
                        if (pressed1 or appuie) and save_1_new:
                            compteur = 0
                            if game.message(ligne1="Êtes-vous sûr de vouloir prendre la 1ère sauvegarde ?",choice = True):
                                game.save.new_game(1)
                                game.load_player(1)
                                lancement = True
                                menu_new_game = False
                                is_new = True
                            else:
                                if music:
                                    pygame.mixer.music.load('assets\start_menu.ogg')
                                    pygame.mixer.music.play(-1)
                        elif pressed1 or appuie:
                            game.message(ligne1="Cette partie contient déjà des données. Si vous voulez", ligne2=" l'utiliser, veuillez supprimer les données de cette sauvegarde.")
                            if music:
                                pygame.mixer.music.load('assets\start_menu.ogg')
                                pygame.mixer.music.play(-1)
                    if (Save_2_rect.collidepoint(pos4) and compteur>5 and not(manette_used)) or (selecteur == 2 and manette_used and compteur > 5):
                        play_button = pygame.image.load('assets/play_button_mousing.png')
                        play_button = pygame.transform.scale(play_button,(abs(Save_2_rect.w+30),abs(Save_2_rect.h+20)))
                        play_button_rect = play_button.get_rect()
                        play_button_rect.x = Save_2_rect.x-10
                        play_button_rect.y = Save_2_rect.y-10
                        screen.blit(play_button,play_button_rect)
                        if (pressed1 or appuie) and save_2_new:
                            compteur = 0
                            if game.message(ligne1="Êtes-vous sûr de vouloir prendre la 2ère sauvegarde ?",choice = True):
                                game.save.new_game(2)  #Pour lancer une sauvegarde, on la réinitialise, puis on la lance, avec les fonctions de save.
                                game.load_player(2)
                                lancement = True
                                menu_new_game = False
                                is_new = True
                            else:
                                if music:
                                    pygame.mixer.music.load('assets\start_menu.ogg')
                                    pygame.mixer.music.play(-1)
                        elif pressed1 or appuie:
                            game.message(ligne1="Cette partie contient déjà des données. Si vous voulez", ligne2=" l'utiliser, veuillez supprimer les données de cette sauvegarde.")
                            if music:
                                pygame.mixer.music.load('assets\start_menu.ogg')
                                pygame.mixer.music.play(-1)
                            compteur = 0
                    if (Save_3_rect.collidepoint(pos4) and compteur>5 and not(manette_used)) or (selecteur == 3 and manette_used and compteur > 5):
                        play_button = pygame.image.load('assets/play_button_mousing.png')
                        play_button = pygame.transform.scale(play_button,(abs(Save_3_rect.w+30),abs(Save_3_rect.h+20)))
                        play_button_rect = play_button.get_rect()
                        play_button_rect.x = Save_3_rect.x-10
                        play_button_rect.y = Save_3_rect.y-10
                        screen.blit(play_button,play_button_rect)
                        if (pressed1 or appuie) and save_3_new:
                            compteur = 0
                            if game.message(ligne1="Êtes-vous sûr de vouloir prendre la 3ème sauvegarde ?",choice = True):
                                game.save.new_game(3)
                                game.load_player(3)
                                lancement = True
                                menu_new_game = False
                                is_new = True
                            else:
                                if music:
                                    pygame.mixer.music.load('assets\start_menu.ogg')
                                    pygame.mixer.music.play(-1)
                        elif pressed1 or appuie:
                            game.message(ligne1="Cette partie contient déjà des données. Si vous voulez", ligne2=" l'utiliser, veuillez supprimer les données de cette sauvegarde.")
                            if music:
                                pygame.mixer.music.load('assets\start_menu.ogg')
                                pygame.mixer.music.play(-1)
                            compteur = 0
                    if (retour_rect.collidepoint(pos4) and not(manette_used)) or back or (selecteur == 0 and manette_used and compteur > 5):
                        play_button = pygame.image.load('assets/play_button_mousing.png')
                        play_button = pygame.transform.scale(play_button,(abs(retour_rect.w+30),abs(retour_rect.h+20)))
                        play_button_rect = play_button.get_rect()
                        play_button_rect.x = retour_rect.x-10
                        play_button_rect.y = retour_rect.y-10
                        screen.blit(play_button,play_button_rect)
                        if pressed1 or appuie or back:
                            menu_new_game = False
                            compteur = 0
                    pygame.display.flip()
                    time.sleep(1/60)
                    compteur+=1
        elif (continue_game_rect.collidepoint(pos) and not(manette_used)) or (selecteur == 1 and manette_used ):
            font2=pygame.font.Font(None, 40)
            if game.save.is_new_game(1):
                Save_1 = font2.render("Savegarde 1: Aucune Donnée",1,game.color.black())
                save_1_new = True
            else:
                conn = sqlite3.connect('save.db')
                cursor = conn.cursor()
                cursor.execute("""SELECT save_name,player_level FROM save_information WHERE id = ?""","1")
                info = cursor.fetchone()
                Save_1 = font2.render("Savegarde 1: "+str(info[0])+" - Lv."+str(info[1]),1,game.color.black())
                save_1_new = False
                                            
            if game.save.is_new_game(2):
                Save_2 = font2.render("Savegarde 2: Aucune Donnée",1,game.color.black())
                save_2_new = True
            else:
                conn = sqlite3.connect('save.db')
                cursor = conn.cursor()
                cursor.execute("""SELECT save_name,player_level FROM save_information WHERE id = ?""","2")
                info = cursor.fetchone()
                Save_2 = font2.render("Savegarde 2: "+str(info[0])+" - Lv."+str(info[1]),1,game.color.black())
                save_2_new = False
                                            
            if game.save.is_new_game(3):
                Save_3 = font2.render("Savegarde 3: Aucune Donnée",1,game.color.black())
                save_3_new = True
            else:
                conn = sqlite3.connect('save.db')
                cursor = conn.cursor()
                cursor.execute("""SELECT save_name,player_level FROM save_information WHERE id = ?""","3")
                info = cursor.fetchone()
                Save_3 = font2.render("Savegarde 3: "+str(info[0])+" - Lv."+str(info[1]),1,game.color.black())
                save_3_new = False
            retour = font2.render("Retour",1,game.color.black())
            copier = font2.render("Copier",1,game.color.black())
            play_button = pygame.image.load('assets/play_button_mousing.png')
            play_button = pygame.transform.scale(play_button,(abs(continue_game_rect.w),abs(continue_game_rect.h)))
            play_button_rect = play_button.get_rect()
            play_button_rect.x = continue_game_rect.x
            play_button_rect.y = continue_game_rect.y
            screen.blit(play_button,play_button_rect)
            pos_test = pygame.mouse.get_pos()
            if pressed1 or appuie:
                selecteur = 1
                menu_continue = True
                compteur = 0
                appuie = False
                back = False
                while menu_continue:
                    screen.blit(game.background,game.background_rect)
                    retour = font2.render("Retour",1,(0,0,0))
                    for event in pygame.event.get():
                        if pygame.joystick.get_init():
                            if event.type == pygame.JOYBUTTONDOWN:
                                if event.button == 0:
                                    appuie = True
                                elif event.button == 1:
                                    back = True
                            elif event.type == pygame.JOYBUTTONUP:
                                if event.button == 0:
                                    appuie = False
                                elif event.button == 1:
                                    back = False
                            elif event.type == pygame.JOYHATMOTION:
                                if manette_used == False:
                                    manette_used = True
                                    selecteur = 1
                                elif event.value[1] != 0:
                                    if event.value[1] == 1 and selecteur>0: #Haut
                                        selecteur -= 1
                                    elif event.value[1] == -1 and selecteur<3: #Bas
                                        selecteur += 1
                        else:
                            pass
                    Save_1_rect = Save_1.get_rect()
                    Save_2_rect = Save_2.get_rect()
                    Save_3_rect = Save_3.get_rect()
                    retour_rect = retour.get_rect()
                    Save_1_rect.x = Save_2_rect.x = Save_3_rect.x = screen.get_width()/4+5
                    Save_1_rect.y = 200
                    Save_2_rect.y = 400
                    Save_3_rect.y = 600
                    retour_rect.x = 20
                    retour_rect_y = 900
                    screen.blit(Save_1, Save_1_rect)
                    screen.blit(Save_2, Save_2_rect)
                    screen.blit(Save_3, Save_3_rect)
                    screen.blit(retour,retour_rect)
                    pos2 = pygame.mouse.get_pos()
                    if pos2 != pos_test:
                        manette_used = False
                        pos_test = pos2
                    pressed1, pressed2, pressed3 = pygame.mouse.get_pressed()
                    if (Save_1_rect.collidepoint(pos2) and compteur>5 and not(manette_used)) or (selecteur == 1 and manette_used and compteur > 5):
                        play_button = pygame.image.load('assets/play_button_mousing.png')
                        play_button = pygame.transform.scale(play_button,(abs(Save_1_rect.w+30),abs(Save_1_rect.h+20)))
                        play_button_rect = play_button.get_rect()
                        play_button_rect.x = Save_1_rect.x-10
                        play_button_rect.y = Save_1_rect.y-10
                        screen.blit(play_button,play_button_rect)
                        if (pressed1 or appuie) and not save_1_new:
                            compteur = 0
                            if game.message(ligne1="Êtes-vous sûr de vouloir prendre la 1ère sauvegarde ?",choice = True):
                                game.load_player(1) #Pour lancer une sauvegarde normale, il suffit de la charger
                                lancement = True
                                menu_continue = False
                            else:
                                if music:
                                    pygame.mixer.music.load('assets\start_menu.ogg')
                                    pygame.mixer.music.play(-1)
                        elif (pressed1 or appuie) and save_1_new:
                            game.message(ligne1 = "Cette sauvegarde ne contient pas de sauvegarde.")
                    if (Save_2_rect.collidepoint(pos2) and compteur>5 and not(manette_used)) or (selecteur == 2 and manette_used and compteur > 5):
                        play_button = pygame.image.load('assets/play_button_mousing.png')
                        play_button = pygame.transform.scale(play_button,(abs(Save_2_rect.w+30),abs(Save_2_rect.h+20)))
                        play_button_rect = play_button.get_rect()
                        play_button_rect.x = Save_2_rect.x-10
                        play_button_rect.y = Save_2_rect.y-10
                        screen.blit(play_button,play_button_rect)
                        if (pressed1 or appuie) and not save_2_new:
                            compteur = 0
                            if game.message(ligne1="Êtes-vous sûr de vouloir prendre la 2ème sauvegarde ?",choice = True):
                                game.load_player(2)
                                lancement = True
                                menu_continue = False
                            else:
                                if music:
                                    pygame.mixer.music.load('assets\start_menu.ogg')
                                    pygame.mixer.music.play(-1)
                        elif (pressed1 or appuie) and save_2_new:
                            game.message(ligne1 = "Cette sauvegarde ne contient pas de sauvegarde.")
                    if (Save_3_rect.collidepoint(pos2) and compteur>5 and not(manette_used)) or (selecteur == 3 and manette_used and compteur > 5):
                        play_button = pygame.image.load('assets/play_button_mousing.png')
                        play_button = pygame.transform.scale(play_button,(abs(Save_3_rect.w+30),abs(Save_3_rect.h+20)))
                        play_button_rect = play_button.get_rect()
                        play_button_rect.x = Save_3_rect.x-10
                        play_button_rect.y = Save_3_rect.y-10
                        screen.blit(play_button,play_button_rect)
                        if (pressed1 or appuie) and not save_3_new:
                            compteur = 0
                            if game.message(ligne1="Êtes-vous sûr de vouloir prendre la 3ème sauvegarde ?",choice = True):
                                game.load_player(3)
                                lancement = True
                                menu_continue = False
                            else:
                                if music:
                                    pygame.mixer.music.load('assets\start_menu.ogg')
                                    pygame.mixer.music.play(-1)
                        elif (pressed1 or appuie) and save_1_new:
                            game.message(ligne1 = "Cette sauvegarde ne contient pas de sauvegarde.")
                    if (retour_rect.collidepoint(pos2) and not(manette_used)) or (selecteur == 0 and manette_used) or back:
                        play_button = pygame.image.load('assets/play_button_mousing.png')
                        play_button = pygame.transform.scale(play_button,(abs(retour_rect.w+30),abs(retour_rect.h+20)))
                        play_button_rect = play_button.get_rect()
                        play_button_rect.x = retour_rect.x-10
                        play_button_rect.y = retour_rect.y-10
                        screen.blit(play_button,play_button_rect)
                        if pressed1 or appuie or back:
                            compteur = 0
                            menu_continue = False
                    pygame.display.flip()
                    time.sleep(1/60)
                    compteur+=1

        elif (option_rect.collidepoint(pos) and not(manette_used)) or (selecteur == 2 and manette_used):
            """Si l'on va dans ce menu, on aura un texte qui nous dira si la musique est activé.
                Si l'on clique dessus, on la désactive, ou on l'active si elle était désactivée.
                Ceci va en même temps modifier la base de donnée du jeu
            """
                
            play_button = pygame.image.load('assets/play_button_mousing.png')
            play_button = pygame.transform.scale(play_button,(abs(option_rect.w+40),abs(option_rect.h+30)))
            play_button_rect = play_button.get_rect()
            play_button_rect.x = option_rect.x-20
            play_button_rect.y = option_rect.y-15
            screen.blit(play_button,play_button_rect)
            if pressed1 or appuie:
                option = True
                game.background = pygame.image.load('assets/neutral_background.png')
                game.background = pygame.transform.scale(game.background,(screen.get_width(),screen.get_height()))
                game.background_rect = game.background.get_rect()
                screen.blit(game.background,game.background_rect)
                screen.blit(continue_game,continue_game_rect)
                retour = font.render("Retour",1,game.color.black())
                retour_rect = retour.get_rect()
                retour_rect.x = 100
                retour_rect.y = 100
                screen.blit(retour,retour_rect)
                appuie = False
                back = False
                pos_test = pygame.mouse.get_pos()
                conn = sqlite3.connect('game_info.db')
                cursor = conn.cursor()
                cursor.execute("""SELECT music FROM option""")
                info = cursor.fetchone()
                if bool(info[0]):
                    affichage = "Musique: Activée"
                else:
                    affichage = "Musique: Désactivée"
                afficher = font.render(affichage,1,game.color.black())
                afficher_rect = afficher.get_rect()
                afficher_rect.x = 200
                afficher_rect.y = 300
                compteur = 0
                selecteur = 0
                while option:
                    conn = sqlite3.connect('game_info.db')
                    cursor = conn.cursor()
                    cursor.execute("""SELECT music FROM option""")
                    info = cursor.fetchone()
                    screen.blit(game.background,game.background_rect)
                    screen.blit(retour,retour_rect)
                    screen.blit(afficher,afficher_rect)
                    for event in pygame.event.get():
                        if pygame.joystick.get_init():
                            if manette_used and not select_new and not select_continue:
                                select_new = True
                            if event.type == pygame.JOYBUTTONDOWN:
                                if event.button == 0:
                                    appuie = True
                                elif event.button == 1:
                                    back = True
                            elif event.type == pygame.JOYBUTTONUP:
                                if event.button == 0:
                                    appuie = False
                                elif event.button == 1:
                                    back = False
                            elif event.type == pygame.JOYHATMOTION:
                                if manette_used == False:
                                    selecteur = 0
                                    manette_used = True
                                elif event.value[1] != 0:
                                    if event.value[1] == 1 and selecteur >0: #Haut
                                        selecteur -= 1
                                    elif event.value[1] == -1 and selecteur<1: #Bas
                                        selecteur += 1
                            
                    else:
                        pass
                    
                    pos2 = pygame.mouse.get_pos()
                    if pos2 != pos_test:
                        manette_used = False
                        pos_test = pos2
                    pressed1, pressed2, pressed3 = pygame.mouse.get_pressed()
                    if (retour_rect.collidepoint(pos2) and not(manette_used)) or (selecteur == 0 and manette_used) or back:
                        play_button = pygame.image.load('assets/play_button_mousing.png')
                        play_button = pygame.transform.scale(play_button,(abs(retour_rect.w+30),abs(retour_rect.h+20)))
                        play_button_rect = play_button.get_rect()
                        play_button_rect.x = retour_rect.x-10
                        play_button_rect.y = retour_rect.y-10
                        screen.blit(play_button,play_button_rect)
                        if pressed1 or appuie or back:
                            option = False
                    if ((afficher_rect.collidepoint(pos2) and not(manette_used and compteur > 5)) or (selecteur ==1 and manette_used and compteur > 5)) :
                        play_button = pygame.image.load('assets/play_button_mousing.png')
                        play_button = pygame.transform.scale(play_button,(abs(afficher_rect.w+30),abs(afficher_rect.h+20)))
                        play_button_rect = play_button.get_rect()
                        play_button_rect.x = afficher_rect.x-10
                        play_button_rect.y = afficher_rect.y-10
                        screen.blit(play_button,play_button_rect)
                        if pressed1 or appuie:
                            compteur = 0
                            if bool(info[0]):
                                affichage = "Musique: Désactivée"
                                afficher = font.render(affichage,1,game.color.black())
                                afficher_rect = afficher.get_rect()
                                afficher_rect.x = 200
                                afficher_rect.y = 300
                                sqliteConnection = sqlite3.connect('game_info.db')
                                cursor = sqliteConnection.cursor()
                                sql_update_query = """UPDATE option SET music = ? WHERE id = 1"""
                                cursor.execute(sql_update_query,str(0))
                                sqliteConnection.commit()
                                music = False
                                pygame.mixer.music.load('assets\start_menu.ogg')
                                pygame.mixer.music.stop()
                                compteur = 0
                            else:
                                affichage = "Musique: Activée"
                                afficher = font.render(affichage,1,game.color.black())
                                afficher_rect = afficher.get_rect()
                                afficher_rect.x = 200
                                afficher_rect.y = 300
                                sqliteConnection = sqlite3.connect('game_info.db')
                                cursor = sqliteConnection.cursor()
                                sql_update_query = """UPDATE option SET music = ? WHERE id = 1"""
                                cursor.execute(sql_update_query,str(1))
                                sqliteConnection.commit()
                                music = True
                                compteur = 0
                                if music:
                                    pygame.mixer.music.load('assets\start_menu.ogg')
                                    pygame.mixer.music.play(-1)
                            time.sleep(0.2)
                    compteur += 1        
                    pygame.display.flip()
                
        elif (quitter_rect.collidepoint(pos) and not(manette_used)) or (selecteur == 3 and manette_used):
            play_button = pygame.image.load('assets/play_button_mousing.png')
            play_button = pygame.transform.scale(play_button,(abs(quitter_rect.w+40),abs(quitter_rect.h+30)))
            play_button_rect = play_button.get_rect()
            play_button_rect.x = quitter_rect.x-20
            play_button_rect.y = quitter_rect.y-15
            screen.blit(play_button,play_button_rect)
            if pressed1 or appuie:
                screen.blit(game.background,game.background_rect)
                pygame.display.flip()
                if game.message(ligne1="Êtes-vous sûr de vouloir quitter ?",choice = True):
                    quit()
                else:
                    if music:
                        pygame.mixer.music.load('assets\start_menu.ogg')
                        pygame.mixer.music.play(-1)
        pygame.display.flip()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                end()
                quit()
        time.sleep(1/60)

def tuto():
    """Fonction qui permet d'afficher au joueur les textes explicant le jeu"""
    global is_new
    global next_tuto
    screen.blit(game.background, game.background_rect)
    screen.blit(game.player.image, game.player.rect)
    game.player.update_health_bar(screen)
    game.message(ligne1="Pour passer ces messages, appuyez sur espace",ligne2="ou sur le bouton 'croix' de la manette")
    game.message(ligne1="Appuyez sur les flèches directionnels ou",ligne2="'q' et 'd' pour vous déplacer")
    game.message(ligne1="Vous pouvez aussi utiliser la manette, avec le joystick",ligne2="ou les croix directionnels")
    game.message(ligne1="Vous devez tuer des méchants pour monter de niveau",ligne2="Ce que représente la barre bleue")
    game.message(ligne1="Lorsque vous tuer un monstre, vous gagnez de l'éxpérience",ligne2="Pour atteindre le prochain niveau, remplissez la barre")
    game.message(ligne1="Votre niveau est indiqué sur la droite de la barre bleue")
    game.message(ligne1="La barre verte est votre niveau de vie",ligne2="Si la barre est entièrement rouge, vous êtes mort")
    game.message(ligne1="Vous êtes alors renvoyer dans le menu principal",ligne2="sans que votre progression soit sauvegardé")
    game.message(ligne1="Pour regagner de la vie, vous devez monter de niveau")
    game.message(ligne1="Montez de niveau augmente aussi votre attaque, vitesse",ligne2="Et la vie maximale")
    game.message(ligne1="Continuez sur la droite, vous atteindrez un château",ligne2="Vous devez vous y rendre")
    is_new = False
    next_tuto = True
    

while not(lancement):
    """Lancement du menu principal"""
    prelancement()
    
"""Fonction interne au jeu permettant de bloquer temporairement des fonctionnalités, ou le joueur"""
next_tuto = False
game.new_zone = False
monster_stop = False
game.in_miniboss_fight = False
joystick = False
first_time_trone = False
first_collide_guard = True
cant_right = False

first_proj = True

projectile_tir = 0
deplacement = False
compteur = 0
nb_attack = 0
compteur_before_damage = 0
degats = False
attente = 0

while lancement:
    """Boucle principale du jeu. C'est ce qui va afficher les objets, faire avancer le joueur, lancer les évènements, etc..."""
    
    #Affichage des éléments principaux du jeu.
    screen.blit(game.background, game.background_rect)
    screen.blit(game.player.image, game.player.rect)
    game.all_monsters.draw(screen)
    
    game.player.update_health_bar(screen) #Mis à jour de la barre de vie du joueur
    
    
    if game.zone != 'into_trone' and not(game.first_time_cinematique) and not(first_time_trone):
        #Vérifie si le joueur est partie du trône
        first_time_trone = True
    
    if game.zone == "into_trone" and game.lieu == "into_castle" and game.princess_pass:
        screen.blit(game.princess.image,game.princess.rect)
    
    if attente > 0: #Permet d'attendre entre chaque attaque, pour éviter la simplicité du jeu
        attente -=1
    
    if (game.zone == 'into_trone' and not(game.first_time_cinematique)) and not(game.princess_pass):
        """Vérifie si le joueur est niveau 10 pour valider la quête. Si c'est le cas, il débloque Magmatown"""
        screen.blit(game.princess.image,game.princess.rect)
        if first_time_trone:
            first_time_trone = False
            if game.player.level < 10:
                game.message(ligne1="Vous n'êtes que niveau "+str(game.player.level)+".",ligne2="Revenez lorsque vous serez niveau 10",speaker="Princesse",speaker_color=game.color.pink())
            else:
                game.message(ligne1="Vous êtes vraiment passé niveau 10 ?",ligne2="Merci infiniment !",speaker = "Princesse", speaker_color = game.color.pink())
                game.message(ligne1="Je comprends donc que vous voulez nous aider !",ligne2="Donc laissez moi vous expliquer.", speaker = "Princesse", speaker_color = game.color.pink())
                game.message(ligne1="La princesse du royaume voisin",ligne2="a arrêté de commercer avec nous.", speaker = "Princesse", speaker_color = game.color.pink())
                game.message(ligne1="Aucun des soldats partis en exploration",ligne2="ne sont jamais revenus", speaker = "Princesse", speaker_color = game.color.pink())
                if not(game.message(ligne1="Pourrais-tu y aller ?", speaker_color = game.color.pink(),choice = True)):
                    game.message(ligne1="Tu n'as pas le choix")
                screen.blit(game.background, game.background_rect)
                screen.blit(game.princess.image,game.princess.rect)
                screen.blit(game.player.image, game.player.rect)
                game.message(ligne1="Parfait ! Je vais te donner le pass pour y aller !", speaker = "Princesse", speaker_color = game.color.pink())
                game.message(ligne1="Les monstres sont toujours plus puissants que toi",ligne2="là-bas. Fait attention !", speaker = "Princesse", speaker_color = game.color.pink())
                game.message(ligne1="Tu trouveras le château facilement !", speaker = "Princesse", speaker_color = game.color.pink())
                game.princess_pass = True
    
    if game.zone == "into_trone" and game.lieu == "into_castle" and game.boss_already_fight and not(game.last_cinematique):
        """Dernier message du jeu. Il s'active lorsque l'on va voir la princesse de la forêt après avoir vaincu la princesse de Magmatown"""
        game.message(ligne1="Vous avez réussi à vaincre la princesse ?! ",speaker = "Princesse", speaker_color = game.color.pink())
        game.message(ligne1="Vous êtes...",ligne2="meilleur que je ne le pensais.",speaker = "Princesse", speaker_color = game.color.pink())
        game.message(ligne1="Merci de nous avoir sauvé.",speaker = "Princesse", speaker_color = game.color.pink())
        game.message(ligne1="Vous avez sauvé le royaume !",ligne2="Merci d'avoir joué au jeu !")
        game.message(ligne1="A bientôt !")
        game.last_cinematique = True
    
    if game.boss.pt2:
        """Lance les options de la deuxième phase du boss"""
        game.boss.forward()
        game.boss.update_health_bar_2(screen)
        screen.blit(game.boss.image,game.boss.rect)
        if game.boss.pos == "left" and game.player.rect.x > game.boss.rect.x:
            game.boss.inversion()
            game.boss.speed = -game.boss.speed
        elif game.boss.pos == "right" and game.player.rect.x < game.boss.rect.x:
            game.boss.inversion()
            game.boss.speed = -game.boss.speed
        if game.player.rect.left + 40 <= game.boss.rect.right and game.player.rect.right - 40 >= game.boss.rect.left:
            game.player.damage(game.boss.attack,projectile.pos)
            if game.boss.pos == "left":
                game.player.rect.x -= 50
            else:
                game.player.rect.x += 50
            
        
    
    if compteur_before_damage > 1:
        compteur_before_damage -= 1
    elif compteur_before_damage == 1:
        compteur_before_damage = 0
        game.cant_damage = False
    
    if game.zone == "into_trone" and game.lieu == "into_magma_castle" and not(game.boss_already_fight) and not(game.in_boss_fight) and not(game.boss.pt2):
        """Lancement du combat avec le boss. Ne s'active que la première fois que l'on visite le château de Magmatown"""
        screen.blit(game.boss.image,game.boss.rect)
        game.boss.health = game.boss.max_health
        game.message(ligne1 = "AHAHAHAHAH",speaker = "!!!", speaker_color = game.color.boss_color())
        game.message(ligne1 = "Alors, tu es venu pour me battre ?",ligne2 = "Pour récupérer les soldats emprisonnés ?",speaker = "Princese de Magmatown",speaker_color = game.color.boss_color())
        game.message(ligne1 = "Si tu arrives à me battre, ils seront libérés",ligne2 = "Sinon, tu finiras au cachot !",speaker = "Princesse de Magmatown",speaker_color = game.color.boss_color())
        if not(game.message(ligne1 = "Es-tu prêt ?",speaker = "!!!", speaker_color = game.color.boss_color(),choice = True)):
            game.message(ligne1 = "Dommage !",speaker = "Princesse de Magmatown",speaker_color = game.color.boss_color())
        game.cant_castle = True
        game.cant_transition = True
        game.cant_save = True
        game.in_boss_fight = True
        game.in_attack = True
        
    if game.in_boss_fight:
        """Si le joueur est en combat, cette boucle s'en occupe. Il lance les projectiles et fait bouger la princesse"""
        screen.blit(game.boss.image,game.boss.rect)
        game.all_projectiles.draw(screen) 
        for projectile in game.all_projectiles:
            projectile.forward()
            if game.player.rect.left + 40 <= projectile.rect.right and game.player.rect.right - 40 >= projectile.rect.left:
                game.player.damage(projectile.attack,projectile.pos,projectile = True)
                projectile.remove()
        if game.player.rect.left + 40 <= game.boss.rect.right and game.player.rect.right - 40 >= game.boss.rect.left:
                game.player.damage(game.boss.attack,projectile.pos)
        game.boss.update_health_bar(screen)
        if degats:
            deplacement = True
            degats = False
            projectile_tir = 0
            nb_attack = 0
            compteur = 0
        
        if 1 < game.boss.health <= 100 and len(game.all_monsters) <= 2:
            game.spawn_monster(game.boss.rect.x)
        
        
        if game.in_attack:
            projectile_tir = random.randint(5,8)
            compteur = random.randint(3,6)
            game.in_attack = False
        elif projectile_tir > 1:
            if compteur == 0:
                game.spawn_projectile()
                projectile_tir -= 1
                compteur = random.randint(3,7)
            else:
                compteur -= 1
        elif projectile_tir == 1:
            if compteur ==0:
                game.spawn_projectile()
                projectile_tir = 0
                compteur = 25
            else:
                compteur -= 1
        elif len(game.all_projectiles) == 0:
            if compteur > 1:
                compteur -= 1
            elif compteur == 1:
                compteur = 0
                deplacement = True
        if deplacement:
            if game.boss.pos == "right":
                game.boss.inversion()
                game.boss.rect.x = random.randint(900,1000)
                
            elif game.boss.pos == "left":
                game.boss.inversion()
                game.boss.rect.x = random.randint(0,50)
            deplacement = False
            screen.blit(game.boss.image,game.boss.rect)
            pygame.display.update()
            game.in_attack = True
        
            
        
    
        
    
    
    if game.zone == "castle" and game.lieu == "magmatown":
        """Lancement du combat avec le mini boss. Ne s'active qu'une fois"""
        if not(game.mini_boss_fight) and not(game.in_miniboss_fight):
            game.spawn_monster(900,niveau=50,miniboss = True)
            game.all_monsters.draw(screen)
            pygame.display.update()
            game.cant_save = True
            game.player.can_move = False
            game.cant_transition = True
            monster_stop = True
            game.cant_castle = True
            game.message(ligne1="Alors tu es venu...",speaker = "???",speaker_color = game.color.gray())
            screen.blit(game.background, game.background_rect)
            screen.blit(game.player.image, game.player.rect)
            game.all_monsters.draw(screen)
            pygame.display.update()
            time.sleep(2)
            game.message(ligne1="Mon but est de t'avertir",ligne2="Tu ne peux battre la princesse",speaker = "???",speaker_color = game.color.gray())
            game.message(ligne1="Bats-moi, et tu pourras passer.",speaker = "???",speaker_color = game.color.gray())
            game.player.can_move = True
            monster_stop = False
            game.in_miniboss_fight = True
            
    if not(monster_stop):
        """Fait avancer les monstres"""
        for monster in game.all_monsters:
            monster.forward()
            monster.update_health_bar(screen)
    game.player.next_level() #Si le joueur a assez d'expérience, alors il va monter de niveau
    
    if is_new:
        """Lancement du tuto au début du jeu"""
        if game.message(ligne1="Voulez-vous le tutoriel ?",choice = True):
            tuto()
        else:
            is_new = False
    
    
    if (not(game.lieu == "into_castle" or game.lieu == "into_magma_castle") and game.zone != "castle" and not(game.lieu == "castle" and game.zone == 3) and game.new_zone == True and game.first_time_cinematique == False) and not(game.dont_spawn):
        """Fait apparaitre les monstres"""
        if is_moving_left == True:
            for i in range(random.randint(1,3)):
                game.spawn_monster(random.randint(0,500))
        elif is_moving_right == True:
            for i in range(random.randint(1,3)):
                game.spawn_monster(random.randint(600,screen.get_width()))
        game.new_zone = False
    
    
    if game.player.rect.x < screen.get_width()-65 and end_zone:
        end_zone = False
        game.cant_right = False
    if game.lieu == "castle" and game.zone == 3:
        """Fait apparaitre le garde de la frontière, et bloque le joueur si il n'a pas le pass"""
        if game.guard.pos == 'right':
            game.guard.inversion()
        game.guard.rect.x = 1000
        screen.blit(game.guard.image,game.guard.rect)
        if game.player.rect.collidepoint((game.guard.rect.x,game.guard.rect.y)):
            if first_collide_guard:
                if not(game.princess_pass):
                    cant_right = True
                    game.message(ligne1="Tu ne peux aller par là-bas.",ligne2="Tu n'as pas le pass.",speaker="Guard",speaker_color=game.color.gray())
                    first_collide_guard = False
        elif cant_right == True:
            cant_right = False
            first_collide_guard = True
                    
        
            
            
        
    
    if ((game.pressed.get(pygame.K_RIGHT) or game.pressed.get(pygame.K_d)) and game.player.rect.x < screen.get_width()-55 and game.player.can_move) and not(cant_right):
        """Si le joueur appuie sur les bonnes touches, il bouge alors sur la droite, ou sur la gauche (juste en dessous)"""
        is_moving_right = True
        is_moving_left = False
        game.player.right()
    elif (game.pressed.get(pygame.K_LEFT) or game.pressed.get(pygame.K_q)) and game.player.rect.x > -13 and game.player.can_move:
        is_moving_right = False
        is_moving_left = True
        game.player.left()
        
        
    if game.lieu == "into_castle" or game.lieu == "into_magma_castle":
        """Affiche un message si le joueur tente de sortir par la gauche du château"""
        if game.player.rect.x < -10 and game.zone == "into_1":
            if premier_message_sortie_chateau:
                game.message(ligne1="Pour sortir appuyer sur 'Entrée' ou sur 'Rond'")
                premier_message_sortie_chateau = False
        elif game.first_time_cinematique and game.lieu == "into_castle" and game.player.rect.x > screen.get_width()-60 and game.zone == "into_1":
            """Lance la cinématique du château de la forêt"""
            game.transition_pt1()
            game.player.rect.x = -5
            game.zone = "into_trone"
            game.background = pygame.image.load('assets/'+game.lieu2+'/'+game.lieu+'/into_castle_trone.png')
            game.background = pygame.transform.scale(game.background,(screen.get_width(),screen.get_height()))
            game.transition_pt2()
            cinematique_princesse_chateau()
        elif game.player.rect.x > screen.get_width()-60 and game.zone == "into_1" and not(game.cant_transition):
            """Permet de circuler entre les deux pièces du château (ici du trône vers l'autre salle)"""
            game.player.rect.x = -5
            game.zone = "into_trone"
            game.background = pygame.image.load('assets/'+game.lieu2+'/'+game.lieu+'/into_castle_trone.png')
            game.background = pygame.transform.scale(game.background,(screen.get_width(),screen.get_height()))
            
            
    elif game.player.rect.x > screen.get_width()-60 and game.zone=="castle" and game.lieu == 'magmatown' and not end_zone:
        """Indique au joueur qu'il a atteint le bout de la map"""
        game.message(ligne1="Vous ne pouvez pas continuer")
        game.cant_right = True
        end_zone = True
    elif game.player.rect.x > screen.get_width()-60 and game.zone=="castle" and game.lieu == 'magmatown' and end_zone:
        """Empêche le jeu d'afficher un message en boucle"""
        print(end="")
    elif game.lieu == "castle" and game.zone == "castle" and game.player.rect.x > screen.get_width()-60:
        """Change la zone du joueur"""
        game.zone_change_right()
    elif game.player.rect.x > screen.get_width()-60 and (game.lieu=="Forest" or game.zone<3):
        game.zone_change_right()
        if game.first_time_castle and game.zone == 'castle':
            time.sleep(0.1)
            game.message(ligne1="Bienvenue au Château !", ligne2="Appuyez sur 'Entrée' ou sur Rond pour rentrer dedans !")
            game.first_time_castle = False
        elif game.first_time_cinematique and game.lieu == "into_castle" and game.zone == 'into_trone':
            cinematique_princesse_chateau()
    
    if game.player.rect.x < -10 and (game.lieu == "into_castle" or game.lieu == "into_magma_castle") and (game.lieu != "into_magma_castle" or (game.lieu == "into_magma_castle" and not(game.cant_transition))):
        """Changement de zone dans le château"""
        if game.zone == "into_trone":
            game.zone = "into_1"
            game.player.rect.x = screen.get_width()-63
            game.background = pygame.image.load('assets/'+game.lieu2+'/'+game.lieu+'/into_castle_1.png')
            game.background = pygame.transform.scale(game.background,(screen.get_width(),screen.get_height()))
    elif game.cant_transition:
        pass
    elif game.player.rect.x < -10 and game.zone == "castle" and game.lieu == "castle":
        game.zone_change_left()
    elif game.player.rect.x > screen.get_width()-60 and (game.lieu=="magmatown" and game.zone==3):
        game.zone_change_right()
    elif  game.lieu == "castle" and game.zone == 3 and game.player.rect.x > screen.get_width()-60:
        game.zone_change_right()
    elif game.player.rect.x < -10 and game.lieu == "magmatown" and (game.zone == "castle" or type(game.zone) == int):
        game.zone_change_left()
    elif game.player.rect.x < -10 and (game.zone > 1 or game.lieu == 'castle'):
        game.zone_change_left()
    


    for event in pygame.event.get():
        """Liste de tous les entrées possibles que doit récupérer Pygame"""
        """Ici il ne s'agit que de ceux pour une manette"""
        if pygame.joystick.get_init(): #Pour éviter tout problème, le jeu ne regardera les entrées manette que si il y en a une qui est branché.
            if event.type == pygame.JOYAXISMOTION: #Le joystick
                if event.axis == 0 and event.value > 0.5:
                    game.pressed[pygame.K_RIGHT] = True
                    game.pressed[pygame.K_LEFT] = False
                    joystick = True
                elif event.axis == 0 and event.value < -0.5:
                    game.pressed[pygame.K_RIGHT] = False
                    game.pressed[pygame.K_LEFT] = True
                    joystick = True
                elif event.axis == 0 and (event.value < 0.5 or event.value >-0.5) and joystick:
                    game.pressed[pygame.K_RIGHT] = False
                    game.pressed[pygame.K_LEFT] = False
                    joystick = False
            if event.type == pygame.JOYHATMOTION: #Les flèches directionnels
                if event.value[1] == 0:
                    if event.value[0] == -1: #Gauche
                        game.pressed[pygame.K_RIGHT] = False
                        game.pressed[pygame.K_LEFT] = True
                    elif event.value[0] == 1: #Droite
                        game.pressed[pygame.K_RIGHT] = True
                        game.pressed[pygame.K_LEFT] = False
                    elif event.value[0] == 0:
                        game.pressed[pygame.K_RIGHT] = False
                        game.pressed[pygame.K_LEFT] = False

            if event.type == pygame.JOYBUTTONDOWN: #Les boutons
                if event.button == 0: #Bouton croix ou "A"
                    if in_attack == False:
                        if is_moving_right == True:
                            in_attack = True
                            attack('right')
                        elif is_moving_left == True:
                            in_attack = True
                            attack('left')
                elif event.button == 1: #Bouton rond ou "B"
                    if  game.zone == "castle":
                        game.enter_castle()
                    elif game.zone == "into_1":
                        game.exit_castle()
                elif event.button == 7: #Bouton Option
                    game.menu.lancer_menu()

        if event.type == pygame.QUIT:
            """On arrête de faire tourner la boucle si la fenetre est fermée"""
            end()
            
        """Ici il s'agit des entrées du clavier"""
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                game.menu.lancer_menu()
            elif event.key == pygame.K_x:
                if in_attack == False:
                    if is_moving_right == True:
                        attack('right')
                        in_attack = True
                    elif is_moving_left == True:
                        in_attack = True
                        attack('left')
            elif event.key == pygame.K_RETURN:
                if game.zone == "castle":
                    game.enter_castle()
                elif game.zone == "into_1":
                    game.exit_castle()
            
            elif event.key == pygame.K_c and debug_mod:
                exec(input())
            elif event.key == pygame.K_m and debug_mod:
                game.spawn_monster(600)
            else:
                game.pressed[event.key] = True



        elif event.type == pygame.KEYUP:
            game.pressed[event.key] = False
    
    

    if game.zone==2 and game.player.rect.x > 100 and game.tuto == False:
        """Tutoriel pour connaitre comment tuer un monstre"""
        game.message(ligne1="Pour attaquer, appuyer sur 'X' ou sur le bouton croix",ligne2="de la manette")
        game.tuto = True
        game.spawn_monster(900,niveau=1)


    if in_attack == True:
        in_attack = False
    pygame.display.update()
    #fixer le nombre de FPS sur ma clock
    if game.player.health<=0:
        """Lorsque le joueur meurt, les variables internes doivent être remis à 0 si le joueur veut relancer directement
            Ici nous allons donc vérifier toutes ces variables, et les remettre à 0, avant de renvoyer le joueur dans le menu principal"""
        game.all_monsters = pygame.sprite.Group()
        game.all_projectiles = pygame.sprite.Group()
        if game.in_miniboss_fight:
            game.in_miniboss_fight = False
        if game.cant_save:
            game.cant_save = False
        if game.player.can_move == False:
            game.player.cant_move = True
        if game.cant_transition:
            game.cant_transition = False
        if monster_stop:
            monster_stop = False
        if game.cant_castle:
            game.cant_castle = False
        if game.in_boss_fight:
            game.in_boss_fight = False
        if projectile_tir > 0:
            projectile_tir = 0
        if deplacement:
            deplacement = False
        if compteur != 0:
            compteur = 0
        if game.in_attack:
            game.in_attack = False
        if game.boss.pos == "right":
            game.boss.inversion()
            game.boss.rect.x = 800
        if nb_attack != 0:
            nb_attack = 0
        if attente != 0:
            attente = 0
        prelancement()
        game.dont_spawn = True
    
    """Définit les FPS (Frame per second) du jeu. Ici, nous tournons à 30 FPS
        Plus le jeu possède d'image par seconde, plus il sera rapide.
        Veuillez notez que si le nombre d'image a été retenu à 30 fixe, c'est pour plusieurs raison:
        1) Puisque la vitesse du jeu dépend du nombre d'image, tout le monde aurait eu une vitesse différente.
        2) Durant les tests, le jeu devenait beaucoup plus rapide à certains moment, une valeur unique est plus agréable
        3) 30 est le mélange parfait entre rapidité et fluidité.
    """
    time.sleep(1/30)
    



